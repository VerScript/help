// Comprehensive VerScript Knowledge Base & Keyword Database
const VERSCRIPT_HELP_DB = [
  {
    "id": "kw-set",
    "name": "set",
    "category": "keyword",
    "subcategory": "Declaration & Assignment",
    "title": "set — Variable Assignment and Declaration",
    "summary": "Binds an identifier to a computed expression, literal value, or data structure. Supports type annotations, immutable constraints, and reactive bindings.",
    "syntax": "set <identifier> : <expression>\nset <type> <identifier> : <expression>\nset const <identifier> : <expression>",
    "functionalities": [
      {
        "title": "Standard Assignment",
        "desc": "Binds a variable to a value in the current scope using colon assignment syntax.",
        "code": "set greeting : \"Hello, VerScript!\"\nset count : 42\ndisplay greeting ?color=#00FFCC"
      },
      {
        "title": "Explicit Type Constraint",
        "desc": "Ensures the variable only accepts values matching the specified primitive or custom DataType.",
        "code": "set num score : 98.5\nset str username : \"alex_dev\"\nset arr matrix : [[1, 0], [0, 1]]"
      },
      {
        "title": "Immutable Constant Declaration",
        "desc": "Prevents reassignment throughout the lifecycle of the execution environment.",
        "code": "set const MAX_USERS : 1000\n! MAX_USERS : 2000 -> throws ImmutableError"
      }
    ],
    "pairedWith": [
      "const",
      "DataType",
      "temp",
      "inst",
      "static",
      "dynamic"
    ],
    "parameters": [
      {
        "name": "identifier",
        "type": "identifier",
        "desc": "The name of the variable to bind."
      },
      {
        "name": "expression",
        "type": "any",
        "desc": "The evaluated value assigned to the variable."
      },
      {
        "name": "type (optional)",
        "type": "type keyword",
        "desc": "Enforces strict type contracts (num, str, bool, arr, entity)."
      }
    ],
    "returns": "Returns the evaluated value assigned to the identifier.",
    "tags": [
      "assign",
      "variable",
      "let",
      "var",
      "const",
      "declare",
      "binding",
      "store",
      "value",
      "initialize"
    ],
    "example": "set num initialBalance : 500\nset num deposit : 150\nset num total : initialBalance + deposit\ndisplay \"Total Account Balance: $\" + total ?color=#22c55e"
  },
  {
    "id": "kw-display",
    "name": "display",
    "category": "keyword",
    "subcategory": "I/O & Concurrency",
    "title": "display — Standard Console & Terminal Output",
    "summary": "Streams evaluated arguments to standard output. Supports ANSI Truecolor hex styling, inline printing, formatting tags, and multiple arguments.",
    "syntax": "display <expr1> [, <expr2>, ...] [?<attribute>=<value>]",
    "functionalities": [
      {
        "title": "Standard Output with Newline",
        "desc": "Prints evaluated arguments separated by spaces, terminating with a newline character.",
        "code": "display \"Welcome to the VerScript Runtime!\""
      },
      {
        "title": "ANSI Truecolor Styling",
        "desc": "Applies 24-bit RGB/HEX color rendering to the output stream without manual escape sequences.",
        "code": "display \"Status: Online\" ?color=#00FFCC\ndisplay \"Warning: High Latency\" ?color=#f59e0b\ndisplay \"Error: Connection Terminated\" ?color=#ef4444"
      },
      {
        "title": "Inline Printing",
        "desc": "Suppresses trailing newline for continuous line progress bars and streaming prompts.",
        "code": "display \"Loading modules: \" ?inline ?color=#38bdf8\ndisplay \"100% complete\" ?color=#22c55e"
      }
    ],
    "pairedWith": [
      "prompt",
      "?color",
      "?inline",
      "?bg",
      "?bold"
    ],
    "parameters": [
      {
        "name": "expressions",
        "type": "any...",
        "desc": "One or more comma-separated values to display."
      },
      {
        "name": "?color",
        "type": "attribute (hex/name)",
        "desc": "Text foreground color (e.g. ?color=#00FFCC)."
      },
      {
        "name": "?inline",
        "type": "attribute flag",
        "desc": "Suppresses the automatic trailing newline."
      }
    ],
    "returns": "void",
    "tags": [
      "print",
      "output",
      "echo",
      "log",
      "console",
      "terminal",
      "stdout",
      "write",
      "color",
      "ansi"
    ],
    "example": "display \"=== System Telemetry ===\" ?color=#bd00ff\ndisplay \"Uptime: 99.98%\" ?color=#00FFCC\ndisplay \"Load Avg: 0.12\" ?color=#38bdf8"
  },
  {
    "id": "kw-prompt",
    "name": "prompt",
    "category": "keyword",
    "subcategory": "I/O & Concurrency",
    "title": "prompt — Interactive User Input",
    "summary": "Suspends execution to receive interactive user input from stdin, terminal, or IDE interactive runbox.",
    "syntax": "set <var> : prompt [\"Optional Question String\"]",
    "functionalities": [
      {
        "title": "Interactive Console Input",
        "desc": "Prompts the operator and reads a full line of text until carriage return or newline.",
        "code": "set name : prompt \"Enter your name: \"\ndisplay \"Welcome, \" + name + \"!\" ?color=#00FFCC"
      },
      {
        "title": "Numeric Parsing with Input",
        "desc": "Reads user input and parses into a numeric variable for arithmetic computation.",
        "code": "set rawAge : prompt \"Enter your age: \"\nset num age : num(rawAge)\ndisplay \"In 5 years you will be: \" + (age + 5) ?color=#38bdf8"
      }
    ],
    "pairedWith": [
      "set",
      "display",
      "num",
      "str"
    ],
    "parameters": [
      {
        "name": "message (optional)",
        "type": "string",
        "desc": "The invitation string displayed before reading stdin."
      }
    ],
    "returns": "str — The line entered by the operator.",
    "tags": [
      "input",
      "read",
      "stdin",
      "interactive",
      "scan",
      "ask",
      "getline",
      "user",
      "terminal"
    ],
    "example": "set command : prompt \"vrs> \"\nif command == \"exit\" then\n  display \"Exiting session.\" ?color=#ef4444\nelse\n  display \"Executing: \" + command ?color=#00FFCC\nend"
  },
  {
    "id": "kw-def",
    "name": "def",
    "category": "keyword",
    "subcategory": "Procedures & Functions",
    "title": "def — General Procedure and Method Definition",
    "summary": "Declares a callable procedure or function block. Can have side effects, accept arguments, and return values with reply.",
    "syntax": "def <name> ( [arg1, arg2, ...] ):\n  <body>\n  reply <value>",
    "functionalities": [
      {
        "title": "Standard Procedure Definition",
        "desc": "Creates a named reusable code routine with scoped parameters.",
        "code": "def calculateHypotenuse(a, b):\n  reply sqrt(a^2 + b^2)\n\nset hyp : calculateHypotenuse(3, 4)\ndisplay \"Hypotenuse: \" + hyp ?color=#00FFCC"
      },
      {
        "title": "Multi-Argument Function with Logic",
        "desc": "Defines logic containing loops, conditionals, and error guards inside the procedure body.",
        "code": "def findMax(arr):\n  set maxVal : arr[0]\n  loop item in arr:\n    if item > maxVal then set maxVal : item\n  reply maxVal"
      }
    ],
    "pairedWith": [
      "reply",
      "func",
      "method",
      "inbound",
      "outbound",
      "DataType"
    ],
    "parameters": [
      {
        "name": "name",
        "type": "identifier",
        "desc": "Procedure identifier."
      },
      {
        "name": "arguments",
        "type": "identifier list",
        "desc": "Formal parameter names enclosed in parentheses."
      }
    ],
    "returns": "Value specified by the reply statement, or null if void.",
    "tags": [
      "function",
      "procedure",
      "method",
      "subroutine",
      "call",
      "parameter",
      "reply",
      "return",
      "routine"
    ],
    "example": "def greet(name, role):\n  display \"Operator: \" + name + \" [\" + role + \"]\" ?color=#38bdf8\n  reply true\n\ngreet(\"Dr. Aris\", \"Lead Scientist\")"
  },
  {
    "id": "kw-func",
    "name": "func",
    "category": "keyword",
    "subcategory": "Procedures & Functions",
    "title": "func — Pure Function Contract",
    "summary": "Enforces deterministic pure function semantics: zero global side effects, referential transparency, and deterministic outputs.",
    "syntax": "func <name> ( [arg1, arg2, ...] ):\n  <body>\n  reply <value>",
    "functionalities": [
      {
        "title": "Pure Mathematical Transformation",
        "desc": "Guarantees no external variables are mutated; strictly operates on inputs and returns results.",
        "code": "func circleArea(radius):\n  set const pi : 3.1415926535\n  reply pi * radius^2\n\ndisplay circleArea(5) ?color=#00FFCC"
      }
    ],
    "pairedWith": [
      "def",
      "reply",
      "const",
      "num"
    ],
    "parameters": [
      {
        "name": "name",
        "type": "identifier",
        "desc": "Function name."
      },
      {
        "name": "arguments",
        "type": "list",
        "desc": "Inputs passed by value."
      }
    ],
    "returns": "Computed pure result.",
    "tags": [
      "pure",
      "function",
      "deterministic",
      "math",
      "no-side-effects",
      "functional"
    ],
    "example": "func factorial(n):\n  if n <= 1 then reply 1\n  reply n * factorial(n - 1)\n\ndisplay \"5! = \" + factorial(5) ?color=#22c55e"
  },
  {
    "id": "kw-reply",
    "name": "reply",
    "category": "keyword",
    "subcategory": "Control Flow",
    "title": "reply — Function Return Statement",
    "summary": "Terminates the execution of the current procedure, method, or function, transmitting the resulting value back to the caller.",
    "syntax": "reply <expression>",
    "functionalities": [
      {
        "title": "Returning Values to Caller",
        "desc": "Stops execution of the function immediately and passes the evaluated result back.",
        "code": "def multiply(x, y):\n  reply x * y\n\nset res : multiply(6, 7)"
      },
      {
        "title": "Early Exit Guard",
        "desc": "Exits prematurely when validation checks fail.",
        "code": "def validateScore(score):\n  if score < 0 or score > 100 then reply false\n  reply true"
      }
    ],
    "pairedWith": [
      "def",
      "func",
      "method",
      "if"
    ],
    "parameters": [
      {
        "name": "expression",
        "type": "any",
        "desc": "The value returned to the caller."
      }
    ],
    "returns": "Exits current frame and passes the operand.",
    "tags": [
      "return",
      "reply",
      "exit",
      "yield",
      "result",
      "output",
      "back"
    ],
    "example": "def isPrime(n):\n  if n < 2 then reply false\n  loop i from 2 to sqrt(n):\n    if n % i == 0 then reply false\n  reply true"
  },
  {
    "id": "kw-do",
    "name": "do",
    "category": "keyword",
    "subcategory": "Control Flow & Exception Shielding",
    "title": "do — Scoped Execution & Exception Shield",
    "summary": "Creates a protected execution block. When paired with 'unless', provides robust try/catch-style exception shielding against runtime errors.",
    "syntax": "do:\n  <guarded code>\nunless <ErrorName>:\n  <recovery code>",
    "functionalities": [
      {
        "title": "Exception Shielding (Protected Execution)",
        "desc": "Catches critical errors without aborting the program, routing into recovery logic.",
        "code": "do:\n  set res : 100 / 0\nunless DivisionByZeroError:\n  display \"Interception: Cannot divide by zero!\" ?color=#f59e0b\n  set res : 0"
      },
      {
        "title": "Isolated Local Scope Block",
        "desc": "Executes a block with local variable isolation; variables declared inside do not leak outward.",
        "code": "do:\n  set tempKey : \"secret_token_123\"\n  display \"Key loaded in isolated scope\"\n! tempKey is out of scope here"
      }
    ],
    "pairedWith": [
      "unless",
      "internal",
      "external",
      "throw"
    ],
    "parameters": [
      {
        "name": "block",
        "type": "statement block",
        "desc": "The code executed within the protected frame."
      }
    ],
    "returns": "Result of block or recovery block.",
    "tags": [
      "do",
      "try",
      "catch",
      "unless",
      "shield",
      "protect",
      "recover",
      "block",
      "scope",
      "error-handling"
    ],
    "example": "do:\n  load Matrix\n  set inv : Matrix.inv([[1, 2], [2, 4]])\nunless SystemError:\n  display \"Singular matrix detected; fallback to pseudo-inverse.\" ?color=#ef4444"
  },
  {
    "id": "kw-unless",
    "name": "unless",
    "category": "keyword",
    "subcategory": "Control Flow & Exception Shielding",
    "title": "unless — Exception Interception Handler",
    "summary": "Pairs with 'do' to intercept specific or general errors, executing recovery procedures when an exception occurs.",
    "syntax": "do:\n  <body>\nunless [ErrorName]:\n  <fallback>",
    "functionalities": [
      {
        "title": "Specific Error Interception",
        "desc": "Catches only the named error type (e.g. MemoryAllocationError, FileError, DivisionByZeroError).",
        "code": "do:\n  set data : Fs.read(\"non_existent.txt\")\nunless FileError:\n  display \"Missing file; loading defaults.\" ?color=#38bdf8"
      },
      {
        "title": "Catch-All Runtime Interception",
        "desc": "Omitting the error name catches any runtime or syntax error that occurs within the block.",
        "code": "do:\n  riskyOperation()\nunless:\n  display \"Handled generic failure cleanly.\" ?color=#f59e0b"
      }
    ],
    "pairedWith": [
      "do",
      "throw",
      "internal",
      "external"
    ],
    "parameters": [
      {
        "name": "ErrorName (optional)",
        "type": "identifier",
        "desc": "Target exception type to catch."
      }
    ],
    "returns": "Fallback branch value.",
    "tags": [
      "catch",
      "except",
      "unless",
      "recover",
      "fallback",
      "error",
      "handler"
    ],
    "example": "do:\n  set res : 50 / divisor\nunless DivisionByZeroError:\n  set res : 999999\n  display \"Divisor was zero, defaulted to max.\" ?color=#f59e0b"
  },
  {
    "id": "kw-loop",
    "name": "loop",
    "category": "keyword",
    "subcategory": "Iteration & Control Flow",
    "title": "loop — Universal Iteration Engine",
    "summary": "Primary iteration construct in VerScript. Supports range iteration (from...to), step quantifiers (by), collection iteration, and fixed repeats.",
    "syntax": "loop [var] from <start> to <end> [by <step>]:\n  <body>\n\nloop <item> in <collection>:\n  <body>\n\nloop <count>:\n  <body>",
    "functionalities": [
      {
        "title": "Range Iteration with 'from' and 'to'",
        "desc": "Iterates inclusive integer bounds with an index variable.",
        "code": "loop i from 1 to 5:\n  display \"Index: \" + i ?color=#38bdf8"
      },
      {
        "title": "Custom Step with 'by'",
        "desc": "Steps by a custom positive or negative stride through the range.",
        "code": "loop val from 10 to 0 by -2:\n  display \"Countdown: \" + val ?color=#00FFCC"
      },
      {
        "title": "Collection Traversal (in)",
        "desc": "Iterates through array elements directly.",
        "code": "set fruits : [\"Apple\", \"Banana\", \"Cherry\"]\nloop fruit in fruits:\n  display \"Fruit: \" + fruit"
      },
      {
        "title": "Fixed Count Repeat",
        "desc": "Executes the inner body a fixed number of times.",
        "code": "loop 3:\n  display \"Heartbeat ping...\" ?color=#22c55e"
      }
    ],
    "pairedWith": [
      "from",
      "to",
      "by",
      "step",
      "cycle",
      "while",
      "until"
    ],
    "parameters": [
      {
        "name": "start / from",
        "type": "num",
        "desc": "Starting index."
      },
      {
        "name": "end / to",
        "type": "num",
        "desc": "Ending bound (inclusive)."
      },
      {
        "name": "step / by",
        "type": "num",
        "desc": "Stride increment or decrement."
      }
    ],
    "returns": "void",
    "tags": [
      "loop",
      "for",
      "iteration",
      "repeat",
      "range",
      "from",
      "to",
      "by",
      "step",
      "iterate",
      "array"
    ],
    "example": "set primes : []\nloop num from 2 to 20:\n  set isP : true\n  loop d from 2 to (num - 1):\n    if num % d == 0 then set isP : false\n  if isP then primes.push(num)\ndisplay \"Primes: \" + primes ?color=#00FFCC"
  },
  {
    "id": "kw-if",
    "name": "if",
    "category": "keyword",
    "subcategory": "Conditional Control Flow",
    "title": "if — Conditional Branching",
    "summary": "Evaluates a boolean condition, executing the 'then' block if true, or the optional 'else' block if false.",
    "syntax": "if <condition> then\n  <consequent>\n[else\n  <alternative>]",
    "functionalities": [
      {
        "title": "Basic Conditional Branch",
        "desc": "Executes code if expression evaluates to true.",
        "code": "if score >= 90 then\n  display \"Grade: A\" ?color=#22c55e\nelse\n  display \"Keep practicing\" ?color=#f59e0b"
      },
      {
        "title": "One-Line Conditional",
        "desc": "Compact inline branch execution.",
        "code": "if temp > 100 then display \"Overheating!\" ?color=#ef4444"
      }
    ],
    "pairedWith": [
      "then",
      "else",
      "guard",
      "match"
    ],
    "parameters": [
      {
        "name": "condition",
        "type": "bool",
        "desc": "Expression evaluating to true or false."
      }
    ],
    "returns": "Branch result if used as expression.",
    "tags": [
      "if",
      "then",
      "else",
      "conditional",
      "branch",
      "when",
      "check",
      "decision"
    ],
    "example": "set speed : 120\nif speed > 100 then\n  display \"ALERT: Speed limit exceeded!\" ?color=#ef4444\nelse\n  display \"Speed within normal parameters.\" ?color=#22c55e"
  },
  {
    "id": "kw-match",
    "name": "match",
    "category": "keyword",
    "subcategory": "Conditional Control Flow",
    "title": "match — Pattern Matching and Multi-Case Branching",
    "summary": "Tests a subject against multiple pattern branches with structural deconstruction and type matching.",
    "syntax": "match <subject> with:\n  case <pattern1>: <action1>\n  case <pattern2>: <action2>\n  case _: <default_action>",
    "functionalities": [
      {
        "title": "Structural Multi-Case Matching",
        "desc": "Replaces cumbersome if-else ladders with clean pattern branches.",
        "code": "set code : 200\nmatch code with:\n  case 200: display \"OK\" ?color=#22c55e\n  case 404: display \"Not Found\" ?color=#f59e0b\n  case 500: display \"Server Error\" ?color=#ef4444\n  case _:   display \"Unknown Code\""
      }
    ],
    "pairedWith": [
      "with",
      "case",
      "if"
    ],
    "parameters": [
      {
        "name": "subject",
        "type": "any",
        "desc": "The value inspected."
      },
      {
        "name": "cases",
        "type": "pattern list",
        "desc": "Branch targets."
      }
    ],
    "returns": "Evaluated branch value.",
    "tags": [
      "match",
      "switch",
      "case",
      "pattern",
      "with",
      "dispatch",
      "branch"
    ],
    "example": "set role : \"admin\"\nmatch role with:\n  case \"admin\": display \"Full Root Permissions\" ?color=#00FFCC\n  case \"user\":  display \"Standard Access\" ?color=#38bdf8\n  case _:       display \"Guest Mode\""
  },
  {
    "id": "kw-load",
    "name": "load",
    "category": "keyword",
    "subcategory": "Module & Library System",
    "title": "load — Dynamic Standard Library Loader",
    "summary": "Loads one or more VerScript standard libraries into the execution environment. Supports comma-separated multi-loading.",
    "syntax": "load <Library1> [, <Library2>, ...]",
    "functionalities": [
      {
        "title": "Single Library Loading",
        "desc": "Imports a specific standard library (e.g. Matrix, Crypto, Stats, Math, Fs, Json).",
        "code": "load Matrix\nset m : Matrix.identity(3)\ndisplay m ?color=#00FFCC"
      },
      {
        "title": "Multi-Library Batch Loading",
        "desc": "Loads multiple modules in a single clean directive.",
        "code": "load Matrix, Crypto, Math, Stats\ndisplay \"All 4 libraries loaded successfully!\" ?color=#22c55e"
      }
    ],
    "pairedWith": [
      "import",
      "lib",
      "inject"
    ],
    "parameters": [
      {
        "name": "libraries",
        "type": "identifiers...",
        "desc": "Names of stdlib modules to load."
      }
    ],
    "returns": "void",
    "tags": [
      "load",
      "import",
      "require",
      "module",
      "library",
      "stdlib",
      "package",
      "use"
    ],
    "example": "load Crypto, Json\nset payload : Json.stringify({ user: \"alex\", role: \"admin\" })\nset hash : Crypto.sha256(payload)\ndisplay \"Payload Hash: \" + hash ?color=#00FFCC"
  },
  {
    "id": "kw-inject",
    "name": "inject",
    "category": "keyword",
    "subcategory": "Polyglot & Metaprogramming",
    "title": "inject — In-Line Polyglot Code Injection",
    "summary": "Executes embedded foreign language code directly within VerScript, with automatic cross-runtime variable marshalling.",
    "syntax": "inject <language>:\n  <foreign code block>",
    "functionalities": [
      {
        "title": "Embedded Python Execution",
        "desc": "Invokes Python runtime and imports libraries like NumPy or SciPy directly.",
        "code": "inject python:\n  import math\n  print(\"Python computed pi:\", math.pi)"
      },
      {
        "title": "Embedded C Execution",
        "desc": "Compiles and executes high-performance native C code in-process.",
        "code": "inject c:\n  printf(\"Native C hardware execution\\n\");"
      }
    ],
    "pairedWith": [
      "load",
      "alias",
      "DataType"
    ],
    "parameters": [
      {
        "name": "language",
        "type": "identifier",
        "desc": "Target runtime (python, c, js, bash, rust)."
      },
      {
        "name": "code block",
        "type": "indented block",
        "desc": "Foreign source code to execute."
      }
    ],
    "returns": "Exported foreign symbols or standard output.",
    "tags": [
      "inject",
      "polyglot",
      "python",
      "c",
      "javascript",
      "interop",
      "foreign",
      "embedded",
      "bridge"
    ],
    "example": "inject js:\n  const now = new Date().toISOString();\n  console.log(\"Current ISO timestamp:\", now);"
  },
  {
    "id": "kw-guard",
    "name": "guard",
    "category": "keyword",
    "subcategory": "Control Flow & Watchguards",
    "title": "guard — Memory & Invariant Watchguard",
    "summary": "Establishes a reactive watchguard that monitors an invariant expression, immediately triggering alerts if violated.",
    "syntax": "guard <condition>:\n  <alert_action>",
    "functionalities": [
      {
        "title": "Invariant Assertions",
        "desc": "Guarantees conditions remain true throughout a scope.",
        "code": "guard memoryUsage < 1000000:\n  display \"CRITICAL: Memory threshold exceeded!\" ?color=#ef4444"
      }
    ],
    "pairedWith": [
      "do",
      "unless",
      "throw",
      "DataType"
    ],
    "parameters": [
      {
        "name": "condition",
        "type": "bool",
        "desc": "Invariant expression to check continuously."
      }
    ],
    "returns": "void",
    "tags": [
      "guard",
      "assert",
      "watchdog",
      "invariant",
      "memory",
      "protect",
      "monitor"
    ],
    "example": "set num balance : 500\nguard balance >= 0:\n  display \"Violation: Balance cannot be negative!\" ?color=#ef4444\nset balance : balance - 100"
  },
  {
    "id": "kw-async",
    "name": "async",
    "category": "keyword",
    "subcategory": "Concurrency & Reactive",
    "title": "async — Asynchronous Task Execution",
    "summary": "Spawns an asynchronous concurrent worker thread or fiber, executing the block non-blockingly.",
    "syntax": "async:\n  <body>\n\nset task : async def taskName():\n  <body>",
    "functionalities": [
      {
        "title": "Non-Blocking Background Worker",
        "desc": "Spawns background tasks while the main thread continues.",
        "code": "async:\n  Time.sleep(1000)\n  display \"Background task complete!\" ?color=#22c55e\ndisplay \"Main thread running immediately...\" ?color=#00FFCC"
      }
    ],
    "pairedWith": [
      "sync",
      "chan",
      "send",
      "recv",
      "when"
    ],
    "parameters": [
      {
        "name": "block",
        "type": "statement block",
        "desc": "Code executed asynchronously."
      }
    ],
    "returns": "Async task handle.",
    "tags": [
      "async",
      "await",
      "concurrency",
      "thread",
      "fiber",
      "parallel",
      "non-blocking",
      "task"
    ],
    "example": "set ch : chan 5\nasync:\n  send ch, \"Hello from fiber!\"\nset msg : recv ch\ndisplay \"Received: \" + msg ?color=#00FFCC"
  },
  {
    "id": "kw-chan",
    "name": "chan",
    "category": "keyword",
    "subcategory": "Concurrency & Reactive",
    "title": "chan — CSP Concurrency Channel",
    "summary": "Creates a typed or buffered Communicating Sequential Processes (CSP) channel for thread-safe message passing.",
    "syntax": "set <ch> : chan [bufferSize]",
    "functionalities": [
      {
        "title": "Thread-Safe Channel Creation",
        "desc": "Allocates a message-passing queue used with send and recv.",
        "code": "set jobs : chan 10\nsend jobs, \"Data payload 1\"\nset item : recv jobs"
      }
    ],
    "pairedWith": [
      "send",
      "recv",
      "async",
      "sync"
    ],
    "parameters": [
      {
        "name": "bufferSize (optional)",
        "type": "num",
        "desc": "Maximum buffer capacity before blocking."
      }
    ],
    "returns": "Channel handle.",
    "tags": [
      "chan",
      "channel",
      "queue",
      "message",
      "csp",
      "send",
      "recv",
      "pipe",
      "concurrency"
    ],
    "example": "set messages : chan 3\nsend messages, \"MSG_1\"\nsend messages, \"MSG_2\"\ndisplay recv messages ?color=#00FFCC\ndisplay recv messages ?color=#38bdf8"
  },
  {
    "id": "kw-send",
    "name": "send",
    "category": "keyword",
    "subcategory": "Concurrency & Reactive",
    "title": "send — Transmit Message to Channel",
    "summary": "Pushes a message onto a concurrency channel. Blocks if the channel buffer is saturated.",
    "syntax": "send <channel>, <message>",
    "functionalities": [
      {
        "title": "Channel Transmission",
        "desc": "Sends a value across a concurrency channel to waiting receivers.",
        "code": "set mailbox : chan 5\nsend mailbox, \"New Order Received\""
      }
    ],
    "pairedWith": [
      "recv",
      "chan",
      "async"
    ],
    "parameters": [
      {
        "name": "channel",
        "type": "chan",
        "desc": "Destination channel."
      },
      {
        "name": "message",
        "type": "any",
        "desc": "Payload to transmit."
      }
    ],
    "returns": "bool — true on successful delivery.",
    "tags": [
      "send",
      "channel",
      "push",
      "message",
      "transmit",
      "emit",
      "pipe"
    ],
    "example": "set queue : chan 2\nsend queue, 100\nsend queue, 200"
  },
  {
    "id": "kw-recv",
    "name": "recv",
    "category": "keyword",
    "subcategory": "Concurrency & Reactive",
    "title": "recv — Receive Message from Channel",
    "summary": "Pulls and consumes the next available message from a channel. Blocks if the channel is currently empty.",
    "syntax": "set <msg> : recv <channel>",
    "functionalities": [
      {
        "title": "Channel Message Consumption",
        "desc": "Retrieves a value from a channel queue.",
        "code": "set payload : recv jobQueue\ndisplay \"Processing: \" + payload"
      }
    ],
    "pairedWith": [
      "send",
      "chan",
      "async"
    ],
    "parameters": [
      {
        "name": "channel",
        "type": "chan",
        "desc": "Channel to read from."
      }
    ],
    "returns": "The message object read from the channel.",
    "tags": [
      "recv",
      "receive",
      "channel",
      "pull",
      "consume",
      "pop",
      "message"
    ],
    "example": "set pipe : chan 1\nsend pipe, \"Ping\"\nset reply : recv pipe\ndisplay reply ?color=#00FFCC"
  },
  {
    "id": "kw-emit",
    "name": "emit",
    "category": "keyword",
    "subcategory": "Reactive & Event Architecture",
    "title": "emit — Dispatch Reactive Event",
    "summary": "Fires an event into the global or scoped reactive bus, immediately triggering all matching 'on' listeners.",
    "syntax": "emit <eventName> [, <payload>]",
    "functionalities": [
      {
        "title": "Reactive Event Dispatch",
        "desc": "Triggers event handlers across the runtime asynchronously or synchronously.",
        "code": "emit \"user:login\", { id: 101, username: \"alex\" }"
      }
    ],
    "pairedWith": [
      "on",
      "when",
      "async"
    ],
    "parameters": [
      {
        "name": "eventName",
        "type": "str",
        "desc": "Unique event identifier."
      },
      {
        "name": "payload (optional)",
        "type": "any",
        "desc": "Data passed to listeners."
      }
    ],
    "returns": "void",
    "tags": [
      "emit",
      "event",
      "dispatch",
      "fire",
      "trigger",
      "publish",
      "pubsub"
    ],
    "example": "on \"telemetry:alert\", def(data):\n  display \"ALERT: \" + data ?color=#ef4444\n\nemit \"telemetry:alert\", \"Overheating in core 3\""
  },
  {
    "id": "kw-on",
    "name": "on",
    "category": "keyword",
    "subcategory": "Reactive & Event Architecture",
    "title": "on — Register Reactive Event Listener",
    "summary": "Attaches a callback procedure to listen for specific events fired via 'emit'.",
    "syntax": "on <eventName>, <handler_procedure>",
    "functionalities": [
      {
        "title": "Event Subscription",
        "desc": "Listens for dispatched events and runs the handler with the event payload.",
        "code": "on \"data:synced\", def(payload):\n  display \"Data synchronization complete!\" ?color=#22c55e"
      }
    ],
    "pairedWith": [
      "emit",
      "when",
      "def"
    ],
    "parameters": [
      {
        "name": "eventName",
        "type": "str",
        "desc": "Target event name to observe."
      },
      {
        "name": "handler",
        "type": "procedure",
        "desc": "Callback procedure."
      }
    ],
    "returns": "Subscription ID.",
    "tags": [
      "on",
      "listen",
      "subscribe",
      "event",
      "handler",
      "callback",
      "observer"
    ],
    "example": "on \"payment:success\", def(amount):\n  display \"Payment processed: $\" + amount ?color=#22c55e\n\nemit \"payment:success\", 450"
  },
  {
    "id": "kw-when",
    "name": "when",
    "category": "keyword",
    "subcategory": "Reactive & Event Architecture",
    "title": "when — Reactive Conditional Observer",
    "summary": "Monitors a reactive property or state expression, executing a reaction as soon as the condition transitions to true.",
    "syntax": "when <condition>:\n  <reactive_action>",
    "functionalities": [
      {
        "title": "Reactive State Transition Observer",
        "desc": "Waits until a variable state satisfies a predicate before triggering.",
        "code": "when temperature > 85:\n  display \"Temperature warning active\" ?color=#ef4444"
      }
    ],
    "pairedWith": [
      "on",
      "emit",
      "guard"
    ],
    "parameters": [
      {
        "name": "condition",
        "type": "bool",
        "desc": "State predicate monitored."
      }
    ],
    "returns": "void",
    "tags": [
      "when",
      "reactive",
      "observe",
      "watch",
      "condition",
      "listener",
      "trigger"
    ],
    "example": "set fuelLevel : 10\nwhen fuelLevel < 15:\n  display \"LOW FUEL: Refuel required immediately.\" ?color=#f59e0b"
  },
  {
    "id": "datatype",
    "name": "DataType",
    "category": "datatype",
    "subcategory": "Constrained Types",
    "summary": "Defines a custom named datatype with runtime validation constraints and invariant predicates.",
    "syntax": "DataType <TypeName>:\n  guard <expression_with_it>\n\nDataType <Port>:\n  guard it >= 1 && it <= 65535",
    "details": "The `DataType` construct enables domain-driven type invariants. Any assignment to a variable annotated with this type verifies the `guard` rule against `it` and throws `DataTypeError` upon violation.",
    "parameters": [
      {
        "name": "TypeName",
        "type": "identifier",
        "description": "Name of the constrained custom type."
      },
      {
        "name": "guard",
        "type": "boolean expression using it",
        "description": "Validation invariant."
      }
    ],
    "return_type": "DataType",
    "paired_keywords": [
      "guard",
      "it",
      "set",
      "throw"
    ],
    "example": "DataType PositiveNum:\n  guard it > 0\n\nset PositiveNum count : 5\n! set PositiveNum err : -1  (Throws DataTypeError)",
    "tags": [
      "datatype",
      "constraint",
      "invariant",
      "guard",
      "it",
      "domain-types"
    ]
  },
  {
    "id": "kw-alias",
    "name": "alias",
    "category": "keyword",
    "subcategory": "Declaration & Metaprogramming",
    "title": "alias — Command and Identifier Aliasing",
    "summary": "Creates an alternate identifier or shortcut alias for existing keywords, standard libraries, or procedures.",
    "syntax": "alias <new_name> : <existing_target>",
    "functionalities": [
      {
        "title": "Keyword / Procedure Shortcut",
        "desc": "Provides human-friendly naming or domain-specific language shorthand.",
        "code": "alias print : display\nprint \"Aliased display keyword successfully!\" ?color=#00FFCC"
      },
      {
        "title": "Library Alias",
        "desc": "Shortens verbose standard library paths.",
        "code": "load Matrix\nalias M : Matrix\nset mat : M.identity(3)"
      }
    ],
    "pairedWith": [
      "set",
      "def",
      "load"
    ],
    "parameters": [
      {
        "name": "new_name",
        "type": "identifier",
        "desc": "New alias symbol."
      },
      {
        "name": "existing_target",
        "type": "identifier",
        "desc": "Target symbol or keyword."
      }
    ],
    "returns": "void",
    "tags": [
      "alias",
      "rename",
      "shortcut",
      "typedef",
      "synonym",
      "bind"
    ],
    "example": "alias echo : display\necho \"Hello via echo alias!\" ?color=#38bdf8"
  },
  {
    "id": "kw-class",
    "name": "class",
    "category": "keyword",
    "subcategory": "Object-Oriented Architecture",
    "title": "class — Object-Oriented Blueprint",
    "summary": "Declares an object-oriented class with encapsulated fields, static properties, constructors, and instance methods.",
    "syntax": "class <ClassName>:\n  [static: ...]\n  [dynamic: ...]\n  def init(args):\n    ...",
    "functionalities": [
      {
        "title": "Class Blueprint Definition",
        "desc": "Bundles state and behaviors into an instantiable type.",
        "code": "class Vector2D:\n  def init(x, y):\n    set this.x : x\n    set this.y : y\n  def magnitude():\n    reply sqrt(this.x^2 + this.y^2)\n\nset v : Vector2D(3, 4)\ndisplay v.magnitude() ?color=#00FFCC"
      }
    ],
    "pairedWith": [
      "static",
      "dynamic",
      "method",
      "def",
      "class"
    ],
    "parameters": [
      {
        "name": "ClassName",
        "type": "identifier",
        "desc": "Name of the class."
      }
    ],
    "returns": "Class constructor.",
    "tags": [
      "class",
      "oop",
      "object",
      "blueprint",
      "method",
      "constructor",
      "new",
      "instance"
    ],
    "example": "class BankAccount:\n  def init(holder, balance):\n    set this.holder : holder\n    set this.balance : balance\n  def deposit(amt):\n    set this.balance : this.balance + amt\n    reply this.balance"
  },
  {
    "id": "kw-throw",
    "name": "throw",
    "category": "keyword",
    "subcategory": "Control Flow & Exception Shielding",
    "title": "throw — Raise Custom Exception",
    "summary": "Explicitly raises a named exception or custom error, interrupting standard execution and transferring control to an enclosing 'unless' block.",
    "syntax": "throw <ErrorName> [\"Error message description\"]",
    "functionalities": [
      {
        "title": "Raising Built-in Errors",
        "desc": "Triggers standard exceptions like AssertError, ScopeViolationError, etc.",
        "code": "if balance < amount then\n  throw RuntimeError \"Insufficient funds for withdrawal\""
      }
    ],
    "pairedWith": [
      "do",
      "unless",
      "is_error_name"
    ],
    "parameters": [
      {
        "name": "ErrorName",
        "type": "identifier",
        "desc": "Registered error type."
      },
      {
        "name": "message (optional)",
        "type": "str",
        "desc": "Helpful diagnostic message."
      }
    ],
    "returns": "Unwinds call stack.",
    "tags": [
      "throw",
      "raise",
      "error",
      "exception",
      "abort",
      "panic",
      "fail"
    ],
    "example": "def requirePositive(n):\n  if n <= 0 then throw DomainError \"Value must be positive\"\n  reply n"
  },
  {
    "id": "kw-typeof",
    "name": "typeof",
    "category": "keyword",
    "subcategory": "Type System & Reflection",
    "title": "typeof — Runtime Type Reflection",
    "summary": "Returns the string primitive or class type name of any evaluated operand.",
    "syntax": "typeof <expression>",
    "functionalities": [
      {
        "title": "Inspecting Primitive Types",
        "desc": "Determines whether a value is 'num', 'str', 'bool', 'arr', 'entity', or a custom DataType.",
        "code": "display typeof 42 ?color=#38bdf8      ! \"num\"\ndisplay typeof \"test\" ?color=#38bdf8  ! \"str\"\ndisplay typeof [1, 2] ?color=#38bdf8  ! \"arr\""
      }
    ],
    "pairedWith": [
      "DataType",
      "num",
      "str",
      "bool",
      "arr"
    ],
    "parameters": [
      {
        "name": "expression",
        "type": "any",
        "desc": "Operand to inspect."
      }
    ],
    "returns": "str — Name of the type.",
    "tags": [
      "typeof",
      "type",
      "reflection",
      "inspect",
      "instanceof",
      "is"
    ],
    "example": "def printType(x):\n  display \"Type is: \" + (typeof x) ?color=#00FFCC"
  },
  {
    "id": "lib-matrix",
    "name": "Matrix",
    "category": "library",
    "subcategory": "Standard Library (Math)",
    "title": "Matrix — High-Performance Linear Algebra",
    "summary": "Deterministic linear algebra and matrix operations: determinants, inverses, eigenvalues, decompositions, and element-wise arithmetic.",
    "syntax": "load Matrix\nMatrix.det(m)\nMatrix.inv(m)\nMatrix.mult(a, b)\nMatrix.identity(n)",
    "functionalities": [
      {
        "title": "Matrix Multiplication & Determinants",
        "desc": "Fast native matrix manipulation with C99 determinism.",
        "code": "load Matrix\nset A : [[1, 2], [3, 4]]\nset det : Matrix.det(A)\nset inv : Matrix.inv(A)\ndisplay \"Determinant: \" + det ?color=#00FFCC\ndisplay \"Inverse: \" + inv ?color=#38bdf8"
      },
      {
        "title": "Identity and Zero Matrices",
        "desc": "Generates square identity matrices and dimensioned zero matrices.",
        "code": "load Matrix\nset I : Matrix.identity(3)\ndisplay I ?color=#22c55e"
      }
    ],
    "pairedWith": [
      "Vector",
      "Math",
      "num"
    ],
    "parameters": [
      {
        "name": "matrix",
        "type": "2D array (arr)",
        "desc": "Array of numerical rows."
      }
    ],
    "returns": "Scalar number, transformed matrix array, or vector.",
    "tags": [
      "matrix",
      "linear-algebra",
      "determinant",
      "inverse",
      "math",
      "mult",
      "eigenvalues",
      "vector",
      "dimensions"
    ],
    "example": "load Matrix\nset M : [[2, 1], [5, 7]]\ndisplay \"Det: \" + Matrix.det(M) ?color=#00FFCC\ndisplay \"Trace: \" + Matrix.trace(M) ?color=#38bdf8"
  },
  {
    "id": "lib-crypto",
    "name": "Crypto",
    "category": "library",
    "subcategory": "Standard Library (Security)",
    "title": "Crypto — Cryptographic Hashing and Security",
    "summary": "Cryptographic digest routines including SHA-256, SHA-512, MD5, HMAC generation, and cryptographically secure random bytes.",
    "syntax": "load Crypto\nCrypto.sha256(text)\nCrypto.sha512(text)\nCrypto.hmac(key, data)\nCrypto.randomBytes(count)",
    "functionalities": [
      {
        "title": "SHA-256 Digest Computation",
        "desc": "Computes standard hex-encoded 256-bit hash of string data.",
        "code": "load Crypto\nset digest : Crypto.sha256(\"admin_password_2026\")\ndisplay \"Digest: \" + digest ?color=#00FFCC"
      },
      {
        "title": "HMAC Authentication Signatures",
        "desc": "Generates keyed HMAC digests for API signature verification.",
        "code": "load Crypto\nset sig : Crypto.hmac(\"secret_key\", \"POST /api/v1/trade\")\ndisplay \"Signature: \" + sig ?color=#22c55e"
      }
    ],
    "pairedWith": [
      "Fs",
      "Json",
      "String"
    ],
    "parameters": [
      {
        "name": "data",
        "type": "str",
        "desc": "Data to hash."
      }
    ],
    "returns": "str — Hexadecimal digest string.",
    "tags": [
      "crypto",
      "hash",
      "sha256",
      "sha512",
      "md5",
      "hmac",
      "security",
      "digest",
      "salt",
      "signature"
    ],
    "example": "load Crypto\nset token : Crypto.sha256(\"user_token_seed\")\ndisplay \"Generated Token: \" + token ?color=#00FFCC"
  },
  {
    "id": "lib-stats",
    "name": "Stats",
    "category": "library",
    "subcategory": "Standard Library (Math)",
    "title": "Stats — Statistical Analysis & Probabilities",
    "summary": "Descriptive statistics, variance, standard deviation, linear regression, median, quartiles, and correlation.",
    "syntax": "load Stats\nStats.mean(arr)\nStats.median(arr)\nStats.variance(arr)\nStats.stdDev(arr)",
    "functionalities": [
      {
        "title": "Descriptive Statistics",
        "desc": "Calculates average, median, variance, and standard deviation.",
        "code": "load Stats\nset scores : [88, 92, 79, 95, 100, 85]\ndisplay \"Mean: \" + Stats.mean(scores) ?color=#00FFCC\ndisplay \"StdDev: \" + Stats.stdDev(scores) ?color=#38bdf8"
      }
    ],
    "pairedWith": [
      "Math",
      "Array",
      "Matrix"
    ],
    "parameters": [
      {
        "name": "dataset",
        "type": "arr of num",
        "desc": "Numeric data sample."
      }
    ],
    "returns": "Calculated numeric statistic.",
    "tags": [
      "stats",
      "statistics",
      "mean",
      "median",
      "variance",
      "stddev",
      "average",
      "analytics",
      "regression"
    ],
    "example": "load Stats\nset samples : [12, 15, 18, 22, 30]\ndisplay \"Median: \" + Stats.median(samples) ?color=#22c55e"
  },
  {
    "id": "lib-fs",
    "name": "Fs",
    "category": "library",
    "subcategory": "Standard Library (System)",
    "title": "Fs — File System Operations",
    "summary": "Synchronous and asynchronous file I/O: reading text/binary files, writing files, directory traversal, and path checking.",
    "syntax": "load Fs\nFs.read(path)\nFs.write(path, data)\nFs.exists(path)\nFs.list(dirPath)",
    "functionalities": [
      {
        "title": "Reading and Writing Text Files",
        "desc": "Loads file content into string variables and writes content to disk.",
        "code": "load Fs\nFs.write(\"output.log\", \"System started successfully\\n\")\nset content : Fs.read(\"output.log\")\ndisplay content ?color=#22c55e"
      }
    ],
    "pairedWith": [
      "Json",
      "Sys",
      "do",
      "unless"
    ],
    "parameters": [
      {
        "name": "path",
        "type": "str",
        "desc": "Relative or absolute file path."
      },
      {
        "name": "data",
        "type": "str",
        "desc": "File content to write."
      }
    ],
    "returns": "str / arr / bool depending on method.",
    "tags": [
      "fs",
      "file",
      "read",
      "write",
      "disk",
      "directory",
      "folder",
      "exists",
      "path",
      "io"
    ],
    "example": "load Fs\nif Fs.exists(\"config.json\") then\n  set cfg : Fs.read(\"config.json\")\n  display \"Loaded config.\" ?color=#00FFCC"
  },
  {
    "id": "lib-json",
    "name": "Json",
    "category": "library",
    "subcategory": "Standard Library (Data)",
    "title": "Json — JSON Serialization and Parsing",
    "summary": "Converts VerScript arrays and entity objects to standard JSON strings, and parses JSON strings into native data structures.",
    "syntax": "load Json\nJson.stringify(obj [, pretty])\nJson.parse(jsonString)",
    "functionalities": [
      {
        "title": "Serialization & Deserialization",
        "desc": "Marshals VerScript structures to/from standard JSON text.",
        "code": "load Json\nset raw : '{\"status\":\"ok\",\"code\":200}'\nset data : Json.parse(raw)\ndisplay \"Code: \" + data.code ?color=#22c55e\n\nset serialized : Json.stringify(data, true)\ndisplay serialized ?color=#38bdf8"
      }
    ],
    "pairedWith": [
      "Fs",
      "Http",
      "Net"
    ],
    "parameters": [
      {
        "name": "data",
        "type": "any",
        "desc": "Object to stringify or JSON string to parse."
      }
    ],
    "returns": "Parsed structure or JSON string.",
    "tags": [
      "json",
      "serialize",
      "parse",
      "stringify",
      "data",
      "object",
      "decode",
      "encode"
    ],
    "example": "load Json\nset user : { id: 1, name: \"Ada Lovelace\", verified: true }\nset jsonStr : Json.stringify(user)\ndisplay jsonStr ?color=#00FFCC"
  },
  {
    "id": "err-memory-allocation",
    "name": "MemoryAllocationError",
    "category": "error",
    "subcategory": "Runtime & Memory",
    "title": "MemoryAllocationError — Allocation Failure",
    "summary": "Raised when the operating system or native allocator refuses memory requests due to heap exhaustion or bounds violations.",
    "criticality": "9 / 10",
    "suppressionTier": "Tier 4 (Unsuppressable Fatal)",
    "causes": "Requested buffer exceeds available physical RAM; infinite recursive allocation loops.",
    "remedy": "Check array bounds, verify recursion termination conditions, and free tracked references.",
    "tags": [
      "memory",
      "allocation",
      "heap",
      "ram",
      "fatal",
      "out-of-memory",
      "oom",
      "exhaustion"
    ],
    "example": "do:\n  ! Allocate safe size\n  set safeArr : [1, 2, 3, 4]\nunless MemoryAllocationError:\n  display \"System low on memory; terminating buffers.\" ?color=#ef4444"
  },
  {
    "id": "err-division-by-zero",
    "name": "DivisionByZeroError",
    "category": "error",
    "subcategory": "Arithmetic",
    "title": "DivisionByZeroError — Divide or Modulo by Zero",
    "summary": "Triggered whenever an arithmetic division (/) or remainder (%) operation receives a zero denominator.",
    "criticality": "5 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Dividing a numeric value by 0 or 0.0.",
    "remedy": "Guard divisors with an if check or enclose within a do...unless DivisionByZeroError block.",
    "tags": [
      "division",
      "zero",
      "modulo",
      "arithmetic",
      "divide",
      "math",
      "error"
    ],
    "example": "do:\n  set res : 100 / divisor\nunless DivisionByZeroError:\n  display \"Cannot divide by zero!\" ?color=#f59e0b\n  set res : 0"
  },
  {
    "id": "err-undefined-variable",
    "name": "UndefinedVariableError",
    "category": "error",
    "subcategory": "Scope & Resolution",
    "title": "UndefinedVariableError — Unbound Identifier Read",
    "summary": "Raised when accessing an identifier that has not been declared with 'set', 'def', or passed as an argument in the current scope.",
    "criticality": "3 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Typo in variable name; accessing a variable outside the block where it was declared.",
    "remedy": "Declare variables before reading, check scope boundaries, and review variable spelling.",
    "tags": [
      "undefined",
      "variable",
      "scope",
      "unbound",
      "identifier",
      "missing",
      "name-error"
    ],
    "example": "do:\n  set val : missingVar\nunless UndefinedVariableError:\n  display \"Variable was not defined; fallback activated.\" ?color=#f59e0b"
  },
  {
    "id": "err-scope-violation",
    "name": "ScopeViolationError",
    "category": "error",
    "subcategory": "Purity & Architecture",
    "title": "ScopeViolationError — Scope or Purity Boundary Breach",
    "summary": "Raised when pure functions (func) attempt to mutate external variables or access private/unscoped identifiers.",
    "criticality": "7 / 10",
    "suppressionTier": "Tier 3 (Scoped Suppression)",
    "causes": "Mutating outer scope from inside a pure 'func' or accessing 'private' members externally.",
    "remedy": "Keep pure functions referentially transparent, or switch to 'def' for procedures with side effects.",
    "tags": [
      "scope",
      "purity",
      "mutation",
      "pure",
      "boundary",
      "violation",
      "private"
    ],
    "example": "set globalCount : 0\n! Inside func, modifying globalCount raises ScopeViolationError"
  },
  {
    "id": "err-datatype-error",
    "name": "DataTypeError",
    "category": "error",
    "subcategory": "Type System",
    "title": "DataTypeError — Invariant Constraint Breach",
    "summary": "Raised when assigning a value to a DataType-annotated variable that violates the declared type or guard invariant.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 2 (CriticalErrors compatible)",
    "causes": "Assigning string to num; violating guard predicate in custom DataType.",
    "remedy": "Ensure assigned values satisfy DataType guard conditions before assignment.",
    "tags": [
      "type",
      "datatype",
      "constraint",
      "guard",
      "mismatch",
      "schema",
      "validation"
    ],
    "example": "DataType PositiveNum:\n  val : num\n  guard val > 0\n\ndo:\n  set PositiveNum p : -5\nunless DataTypeError:\n  display \"Validation caught negative value!\" ?color=#ef4444"
  },
  {
    "id": "fn-printing-output",
    "name": "Printing and Console Output",
    "category": "functionality",
    "subcategory": "I/O",
    "title": "How to Print and Format Output in VerScript",
    "summary": "Methods for streaming formatted text, numbers, arrays, and Truecolor ANSI styled messages to the terminal.",
    "recommendedKeywords": [
      "display",
      "prompt",
      "?color",
      "?inline",
      "alias"
    ],
    "tags": [
      "print",
      "output",
      "display",
      "console",
      "log",
      "terminal",
      "color",
      "ansi",
      "write",
      "text",
      "show"
    ],
    "example": "display \"Default white text\"\ndisplay \"Cyan highlighted text\" ?color=#00FFCC\ndisplay \"Loading: \" ?inline ?color=#38bdf8\ndisplay \"Done!\" ?color=#22c55e"
  },
  {
    "id": "fn-exception-handling",
    "name": "Exception Handling & Error Shielding",
    "category": "functionality",
    "subcategory": "Control Flow",
    "title": "How to Catch and Shield Exceptions in VerScript",
    "summary": "Using the 'do...unless' block architecture to intercept runtime errors, prevent crashes, and implement graceful recovery fallbacks.",
    "recommendedKeywords": [
      "do",
      "unless",
      "throw",
      "internal",
      "external"
    ],
    "tags": [
      "try",
      "catch",
      "exception",
      "error",
      "shield",
      "protect",
      "recover",
      "throw",
      "raise",
      "prevent-crash"
    ],
    "example": "do:\n  set result : riskyCalculation()\nunless DivisionByZeroError:\n  display \"Caught division by zero; setting default.\" ?color=#f59e0b\n  set result : 0\nunless:\n  display \"Caught unexpected error.\" ?color=#ef4444\n  set result : null"
  },
  {
    "id": "fn-loops-and-ranges",
    "name": "Loops, Ranges, and Iteration",
    "category": "functionality",
    "subcategory": "Iteration",
    "title": "How to Iterate and Loop Over Numbers and Arrays",
    "summary": "Iterating ranges with 'from...to', stepping with 'by', repeating fixed counts, and iterating arrays with 'in'.",
    "recommendedKeywords": [
      "loop",
      "from",
      "to",
      "by",
      "step",
      "cycle",
      "while",
      "until"
    ],
    "tags": [
      "loop",
      "for",
      "iteration",
      "range",
      "array",
      "step",
      "by",
      "traverse",
      "repeat",
      "each"
    ],
    "example": "! Loop with step\nloop i from 0 to 10 by 2:\n  display \"Even number: \" + i ?color=#38bdf8\n\n! Array iteration\nloop item in [\"alpha\", \"beta\", \"gamma\"]:\n  display \"Item: \" + item ?color=#00FFCC"
  },
  {
    "id": "fn-linear-algebra",
    "name": "Linear Algebra & Matrix Math",
    "category": "functionality",
    "subcategory": "Mathematics",
    "title": "How to Compute Matrix Inverses, Determinants, and Multiplications",
    "summary": "Using the Matrix standard library for high-speed deterministic operations on 2D arrays.",
    "recommendedKeywords": [
      "Matrix",
      "load",
      "Vector",
      "Math"
    ],
    "tags": [
      "matrix",
      "linear-algebra",
      "determinant",
      "inverse",
      "multiply",
      "math",
      "arrays",
      "eigenvalues"
    ],
    "example": "load Matrix\nset A : [[4, 7], [2, 6]]\nset det : Matrix.det(A)\nset inv : Matrix.inv(A)\ndisplay \"Determinant: \" + det ?color=#00FFCC\ndisplay \"Inverse Matrix: \" + inv ?color=#22c55e"
  },
  {
    "id": "fn-concurrency-channels",
    "name": "Concurrency, Threads & CSP Channels",
    "category": "functionality",
    "subcategory": "Concurrency",
    "title": "How to Run Background Fibers and Message Passing",
    "summary": "Spawning concurrent non-blocking workers with 'async' and passing messages through thread-safe 'chan', 'send', and 'recv'.",
    "recommendedKeywords": [
      "async",
      "sync",
      "chan",
      "send",
      "recv"
    ],
    "tags": [
      "async",
      "concurrency",
      "thread",
      "fiber",
      "channel",
      "message",
      "queue",
      "send",
      "recv",
      "parallel"
    ],
    "example": "set queue : chan 2\nasync:\n  Time.sleep(500)\n  send queue, \"Worker finished payload\"\n\nset msg : recv queue\ndisplay \"Master received: \" + msg ?color=#00FFCC"
  },
  {
    "id": "fn-reactive-events",
    "name": "Reactive Events and Listeners",
    "category": "functionality",
    "subcategory": "Reactive",
    "title": "How to Build Event-Driven Architecture with emit and on",
    "summary": "Publishing and subscribing to reactive events across the VerScript runtime without tight coupling.",
    "recommendedKeywords": [
      "emit",
      "on",
      "when",
      "guard"
    ],
    "tags": [
      "events",
      "emit",
      "on",
      "when",
      "listener",
      "subscribe",
      "pubsub",
      "reactive",
      "trigger"
    ],
    "example": "on \"order:created\", def(orderId):\n  display \"Notification sent for order #\" + orderId ?color=#22c55e\n\nemit \"order:created\", 45892"
  },
  {
    "id": "kw-while",
    "name": "while",
    "category": "keyword",
    "subcategory": "Iteration",
    "title": "while — VerScript Language Keyword",
    "summary": "Executes a block continuously as long as the condition evaluates to true.",
    "syntax": "while <condition>:\n  <body>",
    "returns": "void / value",
    "example": "set i : 0\nwhile i < 5:\n  display i\n  set i : i + 1",
    "tags": [
      "while",
      "loop",
      "condition",
      "repeat"
    ]
  },
  {
    "id": "kw-until",
    "name": "until",
    "category": "keyword",
    "subcategory": "Iteration",
    "title": "until — VerScript Language Keyword",
    "summary": "Inverted condition loop; executes until the condition becomes true.",
    "syntax": "until <condition>:\n  <body>",
    "returns": "void / value",
    "example": "set done : false\nuntil done:\n  set done : true",
    "tags": [
      "until",
      "loop",
      "repeat",
      "invert"
    ]
  },
  {
    "id": "kw-repeat",
    "name": "repeat",
    "category": "keyword",
    "subcategory": "Iteration",
    "title": "repeat — VerScript Language Keyword",
    "summary": "Repeats a code block for a given count or while a condition holds.",
    "syntax": "repeat <count>:\n  <body>",
    "returns": "void / value",
    "example": "repeat 3:\n  display \"Ping!\"",
    "tags": [
      "repeat",
      "loop",
      "times"
    ]
  },
  {
    "id": "kw-cycle",
    "name": "cycle",
    "category": "keyword",
    "subcategory": "Iteration",
    "title": "cycle — VerScript Language Keyword",
    "summary": "Cycles through elements in an array or collection indefinitely or for a range.",
    "syntax": "cycle <item> in <arr>:\n  <body>",
    "returns": "void / value",
    "example": "cycle color in [\"red\", \"green\", \"blue\"]:\n  display color",
    "tags": [
      "cycle",
      "loop",
      "round-robin",
      "array"
    ]
  },
  {
    "id": "kw-for",
    "name": "for",
    "category": "keyword",
    "subcategory": "Iteration",
    "title": "for — VerScript Language Keyword",
    "summary": "Iterator loop syntax for stepping through countable sequences.",
    "syntax": "for <i = 0; i < N; i = i + 1>:\n  <body>",
    "returns": "void / value",
    "example": "for <i = 0; i < 3; i = i + 1>:\n  display i",
    "tags": [
      "for",
      "loop",
      "index"
    ]
  },
  {
    "id": "kw-from",
    "name": "from",
    "category": "keyword",
    "subcategory": "Iteration Range",
    "title": "from — VerScript Language Keyword",
    "summary": "Designates the starting bound of a range loop.",
    "syntax": "loop i from <start> to <end>",
    "returns": "void / value",
    "example": "loop i from 1 to 10:\n  display i",
    "tags": [
      "from",
      "range",
      "start",
      "loop"
    ]
  },
  {
    "id": "kw-to",
    "name": "to",
    "category": "keyword",
    "subcategory": "Iteration Range",
    "title": "to — VerScript Language Keyword",
    "summary": "Designates the ending bound of a range loop.",
    "syntax": "loop i from <start> to <end>",
    "returns": "void / value",
    "example": "loop i from 0 to 5:\n  display i",
    "tags": [
      "to",
      "range",
      "end",
      "loop"
    ]
  },
  {
    "id": "kw-by",
    "name": "by",
    "category": "keyword",
    "subcategory": "Iteration Step",
    "title": "by — VerScript Language Keyword",
    "summary": "Specifies the stride increment or decrement for a range loop.",
    "syntax": "loop i from <start> to <end> by <step>",
    "returns": "void / value",
    "example": "loop i from 10 to 0 by -2:\n  display i",
    "tags": [
      "by",
      "step",
      "stride",
      "increment",
      "decrement"
    ]
  },
  {
    "id": "kw-step",
    "name": "step",
    "category": "keyword",
    "subcategory": "Loop Stride Control",
    "title": "step — Customizable Loop Stride",
    "summary": "Controls the increment or decrement stride when iterating over numeric ranges.",
    "syntax": "for i in start .. end step stride:\n    ...",
    "returns": "Advances loop counter by stride value",
    "example": "for i in 0 .. 10 step 2:\n    display \"Even index: \" + i",
    "tags": [
      "step",
      "loop",
      "stride",
      "range"
    ],
    "parameters": "stride (positive integer increment)",
    "pairedWith": "for, in, .."
  },
  {
    "id": "kw-const",
    "name": "const",
    "category": "keyword",
    "subcategory": "Declaration",
    "title": "const — VerScript Language Keyword",
    "summary": "Declares an immutable symbol that cannot be rebound or mutated.",
    "syntax": "set const <name> : <value>",
    "returns": "void / value",
    "example": "set const PI : 3.14159",
    "tags": [
      "const",
      "immutable",
      "constant",
      "final"
    ]
  },
  {
    "id": "kw-static",
    "name": "static",
    "category": "keyword",
    "subcategory": "Scope & Storage",
    "title": "static — VerScript Language Keyword",
    "summary": "Preserves variable value across procedure invocations, or scopes to class namespace.",
    "syntax": "static <var> : <val>",
    "returns": "void / value",
    "example": "class MathUtil:\n  static: def add(a, b): reply a + b",
    "tags": [
      "static",
      "persistent",
      "class-level"
    ]
  },
  {
    "id": "kw-dynamic",
    "name": "dynamic",
    "category": "keyword",
    "subcategory": "Scope & Storage",
    "title": "dynamic — VerScript Language Keyword",
    "summary": "Binds variable dynamically in the execution call stack rather than lexically.",
    "syntax": "dynamic <var> : <val>",
    "returns": "void / value",
    "example": "dynamic logLevel : \"DEBUG\"",
    "tags": [
      "dynamic",
      "scope",
      "stack"
    ]
  },
  {
    "id": "kw-meta",
    "name": "meta",
    "category": "keyword",
    "subcategory": "Metaprogramming",
    "title": "meta — VerScript Language Keyword",
    "summary": "Accesses language reflection metadata and AST introspection tokens.",
    "syntax": "meta: <introspection>",
    "returns": "void / value",
    "example": "meta: display \"Compiling module\"",
    "tags": [
      "meta",
      "reflection",
      "ast",
      "macros"
    ]
  },
  {
    "id": "kw-thisstatic",
    "name": "thisstatic",
    "category": "keyword",
    "subcategory": "Object Orientation",
    "title": "thisstatic — VerScript Language Keyword",
    "summary": "Accesses class-level static properties from within an instance method.",
    "syntax": "thisstatic.<property>",
    "returns": "void / value",
    "example": "thisstatic.instanceCount : thisstatic.instanceCount + 1",
    "tags": [
      "thisstatic",
      "static",
      "class",
      "oop"
    ]
  },
  {
    "id": "kw-public",
    "name": "public",
    "category": "keyword",
    "subcategory": "Visibility",
    "title": "public — VerScript Language Keyword",
    "summary": "Exports a member or symbol outside the module or class boundary.",
    "syntax": "public <def/set/DataType>",
    "returns": "void / value",
    "example": "public def calculateTax(income): reply income * 0.15",
    "tags": [
      "public",
      "export",
      "visible"
    ]
  },
  {
    "id": "kw-private",
    "name": "private",
    "category": "keyword",
    "subcategory": "Visibility",
    "title": "private — VerScript Language Keyword",
    "summary": "Hides member from outside access, encapsulating it within current class/module.",
    "syntax": "private <set/def>",
    "returns": "void / value",
    "example": "private set internalSecret : \"xyz\"",
    "tags": [
      "private",
      "hidden",
      "encapsulation"
    ]
  },
  {
    "id": "kw-inbound",
    "name": "inbound",
    "category": "keyword",
    "subcategory": "Interface Contracts",
    "title": "inbound — VerScript Language Keyword",
    "summary": "Enforces input parameter validation and preconditions on a function entry.",
    "syntax": "inbound: <validation_guard>",
    "returns": "void / value",
    "example": "def divide(a, b):\n  inbound: b != 0\n  reply a / b",
    "tags": [
      "inbound",
      "precondition",
      "contract",
      "require"
    ]
  },
  {
    "id": "kw-outbound",
    "name": "outbound",
    "category": "keyword",
    "subcategory": "Interface Contracts",
    "title": "outbound — VerScript Language Keyword",
    "summary": "Enforces postconditions and return value contracts on function exit.",
    "syntax": "outbound: <return_guard>",
    "returns": "void / value",
    "example": "def getPositive():\n  outbound: it > 0\n  reply 42",
    "tags": [
      "outbound",
      "postcondition",
      "contract",
      "ensure"
    ]
  },
  {
    "id": "kw-outscope",
    "name": "outscope",
    "category": "keyword",
    "subcategory": "Scope Escapes",
    "title": "outscope — VerScript Language Keyword",
    "summary": "Binds a value in the parent lexical scope from within a nested block.",
    "syntax": "outscope <var> : <val>",
    "returns": "void / value",
    "example": "do:\n  outscope leakedVar : 100",
    "tags": [
      "outscope",
      "parent",
      "scope",
      "escape"
    ]
  },
  {
    "id": "kw-temp",
    "name": "temp",
    "category": "keyword",
    "subcategory": "Storage Lifecycles",
    "title": "temp — VerScript Language Keyword",
    "summary": "Declares an ephemeral variable that is automatically discarded after block termination.",
    "syntax": "set temp <var> : <val>",
    "returns": "void / value",
    "example": "set temp buffer : [1, 2, 3]",
    "tags": [
      "temp",
      "ephemeral",
      "short-lived",
      "stack"
    ]
  },
  {
    "id": "kw-inst",
    "name": "inst",
    "category": "keyword",
    "subcategory": "Storage Lifecycles",
    "title": "inst — VerScript Language Keyword",
    "summary": "Eagerly instantiates an object instance into memory.",
    "syntax": "set inst <var> : <Constructor>",
    "returns": "void / value",
    "example": "set inst logger : Logger()",
    "tags": [
      "inst",
      "instance",
      "eager"
    ]
  },
  {
    "id": "kw-del",
    "name": "del",
    "category": "keyword",
    "subcategory": "Lifecycle",
    "title": "del — VerScript Language Keyword",
    "summary": "Deletes a variable or property reference, allowing garbage collection.",
    "syntax": "del <var>",
    "returns": "void / value",
    "example": "del tempCache",
    "tags": [
      "del",
      "delete",
      "free",
      "remove"
    ]
  },
  {
    "id": "kw-import",
    "name": "import",
    "category": "keyword",
    "subcategory": "Module System",
    "title": "import — VerScript Language Keyword",
    "summary": "Imports native modules, headers, or external VerScript packages.",
    "syntax": "import <module> [as <alias>]",
    "returns": "void / value",
    "example": "import \"stdlib/Math.lib.vrs\" as M",
    "tags": [
      "import",
      "module",
      "require",
      "include"
    ]
  },
  {
    "id": "kw-as",
    "name": "as",
    "category": "keyword",
    "subcategory": "Type Casting & Aliasing",
    "title": "as — VerScript Language Keyword",
    "summary": "Casts an expression to a target type or binds an imported module alias.",
    "syntax": "<expr> as <Type>\nimport <mod> as <alias>",
    "returns": "void / value",
    "example": "set n : \"123\" as num",
    "tags": [
      "as",
      "cast",
      "alias",
      "convert"
    ]
  },
  {
    "id": "kw-export",
    "name": "export",
    "category": "keyword",
    "subcategory": "Module System",
    "title": "export — VerScript Language Keyword",
    "summary": "Explicitly exports identifiers from a library file.",
    "syntax": "export <symbol1>, <symbol2>",
    "returns": "void / value",
    "example": "export add, subtract, multiply",
    "tags": [
      "export",
      "public",
      "module",
      "share"
    ]
  },
  {
    "id": "kw-enum",
    "name": "enum",
    "category": "keyword",
    "subcategory": "Type System",
    "title": "enum — VerScript Language Keyword",
    "summary": "Defines an enumerated set of named integer constants.",
    "syntax": "enum <EnumName>:\n  <VAL1>, <VAL2>, ...",
    "returns": "void / value",
    "example": "enum Direction:\n  North, South, East, West",
    "tags": [
      "enum",
      "enumeration",
      "constants"
    ]
  },
  {
    "id": "kw-struct",
    "name": "struct",
    "category": "keyword",
    "subcategory": "Type System",
    "title": "struct — VerScript Language Keyword",
    "summary": "Declares a composite value data structure.",
    "syntax": "struct <Point>:\n  x : num\n  y : num",
    "returns": "void / value",
    "example": "struct Point:\n  x : num\n  y : num",
    "tags": [
      "struct",
      "composite",
      "record",
      "c-struct"
    ]
  },
  {
    "id": "kw-pragma",
    "name": "pragma",
    "category": "keyword",
    "subcategory": "Compiler Directives",
    "title": "pragma — VerScript Language Keyword",
    "summary": "Configures compiler optimizations, suppression tiers, and runtime flags.",
    "syntax": "pragma <directive>",
    "returns": "void / value",
    "example": "pragma SuppressErrors\npragma OptimizeO2",
    "tags": [
      "pragma",
      "compiler",
      "flag",
      "directive"
    ]
  },
  {
    "id": "kw-it",
    "name": "it",
    "category": "keyword",
    "subcategory": "Pipeline & Implicit Receiver",
    "title": "it — VerScript Language Keyword",
    "summary": "Implicit receiver representing the pipelined input in pipeline expressions (|>) or postconditions.",
    "syntax": "<expr> |> <op it>",
    "returns": "void / value",
    "example": "[1, 2, 3] |> it.length",
    "tags": [
      "it",
      "pipeline",
      "receiver",
      "current"
    ]
  },
  {
    "id": "num",
    "name": "num",
    "category": "datatype",
    "subcategory": "Primitive Types",
    "summary": "64-bit IEEE 754 double-precision floating point numeric value, representing integers and decimals seamlessly.",
    "syntax": "set num <name> : <numeric_literal>\nstr a : \"42\"\nset num parsed : a as num",
    "details": "The `num` type in VerScript represents both integer and fractional floating point values. It supports standard arithmetic operators (+, -, *, /, %), bitwise operations, mathematical functions in the Math library, and automatic type inference.",
    "parameters": [
      {
        "name": "literal",
        "type": "integer or float",
        "description": "Any decimal representation, e.g. 42, -10, 3.14159, 1e-4."
      }
    ],
    "return_type": "num",
    "paired_keywords": [
      "DataType",
      "as",
      "set",
      "Math"
    ],
    "example": "set num count : 10\nset num price : 19.99\nset num total : count * price\ndisplay \"Total: \" + total ?color=cyan",
    "tags": [
      "num",
      "number",
      "int",
      "float",
      "double",
      "datatype",
      "primitive",
      "math"
    ]
  },
  {
    "id": "str",
    "name": "str",
    "category": "datatype",
    "subcategory": "Primitive Types",
    "summary": "UTF-8 encoded string sequence with built-in string methods (.length, .substring, .toUpper, etc.).",
    "syntax": "set str <name> : \"string content\"\nstr multiline : \"Line 1\\nLine 2\"",
    "details": "VerScript strings are immutable UTF-8 text sequences. They support dynamic concatenation with the `+` operator, indexing, slicing, safe navigation, and rich methods such as `.split()`, `.trim()`, `.replace()`, and `.indexOf()`.",
    "parameters": [
      {
        "name": "literal",
        "type": "text sequence",
        "description": "Double-quoted string with escape sequences (\\n, \\t, \\\", \\\\)."
      }
    ],
    "return_type": "str",
    "paired_keywords": [
      "display",
      "prompt",
      "as",
      "String"
    ],
    "example": "set str name : \"VerScript\"\nset str greeting : \"Hello \" + name\ndisplay greeting.toUpper()",
    "tags": [
      "str",
      "string",
      "text",
      "utf8",
      "datatype",
      "primitive",
      "char"
    ]
  },
  {
    "id": "bool",
    "name": "bool",
    "category": "datatype",
    "subcategory": "Primitive Types",
    "summary": "Boolean truth flag literal accepting either true or false.",
    "syntax": "set bool <name> : true | false",
    "details": "Used across all conditional control flow branches (if, unless, while, until, match). Boolean expressions evaluate comparison operations (==, !=, <, >, <=, >=) and logical combinations (&&, ||, !).",
    "parameters": [
      {
        "name": "value",
        "type": "boolean",
        "description": "Keyword true or false."
      }
    ],
    "return_type": "bool",
    "paired_keywords": [
      "if",
      "while",
      "until",
      "unless",
      "guard"
    ],
    "example": "set bool active : true\nif active then:\n  display \"System is online!\" ?color=green",
    "tags": [
      "bool",
      "boolean",
      "true",
      "false",
      "datatype",
      "flag",
      "primitive"
    ]
  },
  {
    "id": "arr",
    "name": "arr",
    "category": "datatype",
    "subcategory": "Collections",
    "summary": "Dynamically sized heterogeneous linear collection supporting indexed access, push/pop, and slice operations.",
    "syntax": "set arr <name> : [<elem1>, <elem2>, ...]\nset <elem> : <name>[<index>]",
    "details": "Arrays hold an ordered list of elements of any type. They support indexing with zero-based integer offsets, length querying with `arr.length`, functional pipelines, and iteration loops.",
    "parameters": [
      {
        "name": "elements",
        "type": "comma-separated values",
        "description": "Elements enclosed within square brackets []."
      }
    ],
    "return_type": "arr",
    "paired_keywords": [
      "cycle",
      "loop",
      "iterate",
      "Array",
      "in"
    ],
    "example": "set arr items : [1, \"two\", 3.0, true]\nitems.push(50)\ndisplay \"Length: \" + items.length\ndisplay items[1]",
    "tags": [
      "arr",
      "array",
      "list",
      "collection",
      "datatype",
      "vector",
      "index"
    ]
  },
  {
    "id": "entity",
    "name": "entity",
    "category": "datatype",
    "subcategory": "Object Orientation",
    "summary": "Dynamic object record or instantiated class/library instance holding bound methods and member fields.",
    "syntax": "set entity <name> : <ClassOrLibName>(<args...>)\nset <name>.<prop> : <val>",
    "details": "Entities represent stateful object instances. They can be created from `class` blueprints, `lib` modules with constructors, or dynamic property maps. Entity members are accessed via the dot `.` operator.",
    "parameters": [
      {
        "name": "constructor",
        "type": "Class or Lib invocation",
        "description": "Invocation of a class or library with constructor parameters."
      }
    ],
    "return_type": "entity",
    "paired_keywords": [
      "class",
      "lib",
      "construct",
      "this",
      "inst"
    ],
    "example": "class Point x y:\n  construct:\n    set this.x : x\n    set this.y : y\n\nset p : Point(10, 20)\ndisplay p.x + \", \" + p.y",
    "tags": [
      "entity",
      "object",
      "instance",
      "class",
      "struct",
      "datatype",
      "oop"
    ]
  },
  {
    "id": "lib-math",
    "name": "Math",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Math — Standard Library",
    "summary": "Trigonometric, logarithmic, and advanced mathematical operations.",
    "syntax": "load Math\nMath.sin(x)\nMath.cos(x)\nMath.pow(a, b)",
    "returns": "Module methods & utilities",
    "example": "load Math\nMath.sin(x)\nMath.cos(x)\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "math",
      "sin",
      "cos",
      "pow",
      "sqrt",
      "trig"
    ]
  },
  {
    "id": "lib-vector",
    "name": "Vector",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Vector — Standard Library",
    "summary": "High-speed 2D, 3D, and n-dimensional geometric vector operations (dot, cross, norm).",
    "syntax": "load Vector\nVector.dot(u, v)\nVector.norm(v)\nVector.cross(u, v)",
    "returns": "Module methods & utilities",
    "example": "load Vector\nVector.dot(u, v)\nVector.norm(v)\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "vector",
      "geometry",
      "dot-product",
      "cross-product",
      "physics"
    ]
  },
  {
    "id": "lib-string",
    "name": "String",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "String — Standard Library",
    "summary": "String formatting, regex pattern evaluation, slicing, and transformations.",
    "syntax": "load String\nString.split(s, delim)\nString.replace(s, pat, repl)",
    "returns": "Module methods & utilities",
    "example": "load String\nString.split(s, delim)\nString.replace(s, pat, repl)\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "string",
      "regex",
      "text",
      "format",
      "replace"
    ]
  },
  {
    "id": "lib-array",
    "name": "Array",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Array — Standard Library",
    "summary": "Functional array manipulation: map, filter, reduce, sort, and zip.",
    "syntax": "load Array\nArray.map(arr, fn)\nArray.filter(arr, fn)\nArray.sort(arr)",
    "returns": "Module methods & utilities",
    "example": "load Array\nArray.map(arr, fn)\nArray.filter(arr, fn)\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "array",
      "map",
      "filter",
      "reduce",
      "sort",
      "list"
    ]
  },
  {
    "id": "lib-random",
    "name": "Random",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Random — Standard Library",
    "summary": "Cryptographic and pseudo-random distributions: gaussian, uniform, choice, shuffle.",
    "syntax": "load Random\nRandom.int(min, max)\nRandom.float()\nRandom.choice(arr)",
    "returns": "Module methods & utilities",
    "example": "load Random\nRandom.int(min, max)\nRandom.float()\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "random",
      "rand",
      "dice",
      "shuffle",
      "noise"
    ]
  },
  {
    "id": "lib-color",
    "name": "Color",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Color — Standard Library",
    "summary": "ANSI 24-bit Truecolor terminal palette generation, RGB/HSL conversions, and gradients.",
    "syntax": "load Color\nColor.rgb(r, g, b)\nColor.hex(\"#00FFCC\")",
    "returns": "Module methods & utilities",
    "example": "load Color\nColor.rgb(r, g, b)\nColor.hex(\"#00FFCC\")\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "color",
      "ansi",
      "terminal",
      "rgb",
      "hex",
      "style"
    ]
  },
  {
    "id": "lib-watchdog",
    "name": "Watchdog",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Watchdog — Standard Library",
    "summary": "Hardware memory and execution time watchdogs preventing freeze and leaks.",
    "syntax": "load Watchdog\nWatchdog.arm(maxMs)\nWatchdog.feed()",
    "returns": "Module methods & utilities",
    "example": "load Watchdog\nWatchdog.arm(maxMs)\nWatchdog.feed()\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "watchdog",
      "timeout",
      "guard",
      "leak",
      "monitor"
    ]
  },
  {
    "id": "lib-time",
    "name": "Time",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Time — Standard Library",
    "summary": "High-resolution monotonic timer, epoch timestamps, sleep delay, and date formatting.",
    "syntax": "load Time\nTime.now()\nTime.sleep(ms)\nTime.epoch()",
    "returns": "Module methods & utilities",
    "example": "load Time\nTime.now()\nTime.sleep(ms)\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "time",
      "date",
      "sleep",
      "delay",
      "clock",
      "timer"
    ]
  },
  {
    "id": "lib-net",
    "name": "Net",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Net — Standard Library",
    "summary": "Low-level TCP/UDP socket network communications.",
    "syntax": "load Net\nNet.connect(host, port)\nNet.listen(port)",
    "returns": "Module methods & utilities",
    "example": "load Net\nNet.connect(host, port)\nNet.listen(port)\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "net",
      "tcp",
      "udp",
      "socket",
      "network"
    ]
  },
  {
    "id": "lib-http",
    "name": "Http",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Http — Standard Library",
    "summary": "High-level HTTP/HTTPS client for GET, POST, and REST API requests.",
    "syntax": "load Http\nHttp.get(url)\nHttp.post(url, body)",
    "returns": "Module methods & utilities",
    "example": "load Http\nHttp.get(url)\nHttp.post(url, body)\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "http",
      "https",
      "get",
      "post",
      "api",
      "rest",
      "fetch"
    ]
  },
  {
    "id": "lib-sys",
    "name": "Sys",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Sys — Standard Library",
    "summary": "Operating system inspection: environment variables, arguments, platform, and exit codes.",
    "syntax": "load Sys\nSys.env(\"PATH\")\nSys.args()\nSys.exit(0)",
    "returns": "Module methods & utilities",
    "example": "load Sys\nSys.env(\"PATH\")\nSys.args()\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "sys",
      "os",
      "env",
      "args",
      "platform",
      "exit"
    ]
  },
  {
    "id": "lib-polyserver",
    "name": "Polyserver",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Polyserver — Standard Library",
    "summary": "Dynamic microservice gateway binding internal VerScript endpoints.",
    "syntax": "load Polyserver\nPolyserver.route(\"/api\", handler)",
    "returns": "Module methods & utilities",
    "example": "load Polyserver\nPolyserver.route(\"/api\", handler)\ndisplay \"Library initialized.\" ?color=#00FFCC",
    "tags": [
      "polyserver",
      "server",
      "microservice",
      "gateway",
      "web"
    ]
  },
  {
    "id": "err-invalidoperanderror",
    "name": "InvalidOperandError",
    "category": "error",
    "subcategory": "Expression",
    "title": "InvalidOperandError — Exception Type",
    "summary": "Applying an operator to incompatible types (e.g. adding boolean to array).",
    "criticality": "4 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Applying an operator to incompatible types (e.g. adding boolean to array).",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless InvalidOperandError:\n  display \"Caught InvalidOperandError\" ?color=#f59e0b",
    "tags": [
      "invalidoperanderror",
      "error",
      "exception",
      "expression",
      "failure"
    ]
  },
  {
    "id": "err-indentationerror",
    "name": "IndentationError",
    "category": "error",
    "subcategory": "Syntax",
    "title": "IndentationError — Exception Type",
    "summary": "Mismatched indentation spacing across block boundaries.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 2",
    "causes": "Mismatched indentation spacing across block boundaries.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless IndentationError:\n  display \"Caught IndentationError\" ?color=#f59e0b",
    "tags": [
      "indentationerror",
      "error",
      "exception",
      "syntax",
      "failure"
    ]
  },
  {
    "id": "err-loopiterationerror",
    "name": "LoopIterationError",
    "category": "error",
    "subcategory": "Iteration",
    "title": "LoopIterationError — Exception Type",
    "summary": "Invalid iteration parameters or modifying collection while iterating.",
    "criticality": "4 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Invalid iteration parameters or modifying collection while iterating.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless LoopIterationError:\n  display \"Caught LoopIterationError\" ?color=#f59e0b",
    "tags": [
      "loopiterationerror",
      "error",
      "exception",
      "iteration",
      "failure"
    ]
  },
  {
    "id": "err-looplimiterror",
    "name": "LoopLimitError",
    "category": "error",
    "subcategory": "Iteration",
    "title": "LoopLimitError — Exception Type",
    "summary": "Loop iterations exceeded max execution bound.",
    "criticality": "5 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Loop iterations exceeded max execution bound.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless LoopLimitError:\n  display \"Caught LoopLimitError\" ?color=#f59e0b",
    "tags": [
      "looplimiterror",
      "error",
      "exception",
      "iteration",
      "failure"
    ]
  },
  {
    "id": "err-loopdirectionerror",
    "name": "LoopDirectionError",
    "category": "error",
    "subcategory": "Iteration",
    "title": "LoopDirectionError — Exception Type",
    "summary": "Positive step specified for descending range (e.g. 10 to 0 by +1).",
    "criticality": "4 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Positive step specified for descending range (e.g. 10 to 0 by +1).",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless LoopDirectionError:\n  display \"Caught LoopDirectionError\" ?color=#f59e0b",
    "tags": [
      "loopdirectionerror",
      "error",
      "exception",
      "iteration",
      "failure"
    ]
  },
  {
    "id": "err-loopsteperror",
    "name": "LoopStepError",
    "category": "error",
    "subcategory": "Iteration",
    "title": "LoopStepError — Exception Type",
    "summary": "Step of 0 passed to range loop.",
    "criticality": "4 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Step of 0 passed to range loop.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless LoopStepError:\n  display \"Caught LoopStepError\" ?color=#f59e0b",
    "tags": [
      "loopsteperror",
      "error",
      "exception",
      "iteration",
      "failure"
    ]
  },
  {
    "id": "err-syntaxerror",
    "name": "SyntaxError",
    "category": "error",
    "subcategory": "Parser",
    "title": "SyntaxError — Exception Type",
    "summary": "Invalid token stream or missing required delimiter.",
    "criticality": "7 / 10",
    "suppressionTier": "Tier 3",
    "causes": "Invalid token stream or missing required delimiter.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless SyntaxError:\n  display \"Caught SyntaxError\" ?color=#f59e0b",
    "tags": [
      "syntaxerror",
      "error",
      "exception",
      "parser",
      "failure"
    ]
  },
  {
    "id": "err-runtimeerror",
    "name": "RuntimeError",
    "category": "error",
    "subcategory": "Execution",
    "title": "RuntimeError — Exception Type",
    "summary": "Generic runtime exception during expression evaluation.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 2",
    "causes": "Generic runtime exception during expression evaluation.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless RuntimeError:\n  display \"Caught RuntimeError\" ?color=#f59e0b",
    "tags": [
      "runtimeerror",
      "error",
      "exception",
      "execution",
      "failure"
    ]
  },
  {
    "id": "err-invaliderrornameerror",
    "name": "InvalidErrorNameError",
    "category": "error",
    "subcategory": "Exception",
    "title": "InvalidErrorNameError — Exception Type",
    "summary": "Suppression directive or throw passed an unregistered error name.",
    "criticality": "4 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Suppression directive or throw passed an unregistered error name.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless InvalidErrorNameError:\n  display \"Caught InvalidErrorNameError\" ?color=#f59e0b",
    "tags": [
      "invaliderrornameerror",
      "error",
      "exception",
      "exception",
      "failure"
    ]
  },
  {
    "id": "err-systemerror",
    "name": "SystemError",
    "category": "error",
    "subcategory": "OS",
    "title": "SystemError — Exception Type",
    "summary": "Native operating system call failure.",
    "criticality": "8 / 10",
    "suppressionTier": "Tier 3",
    "causes": "Native operating system call failure.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless SystemError:\n  display \"Caught SystemError\" ?color=#f59e0b",
    "tags": [
      "systemerror",
      "error",
      "exception",
      "os",
      "failure"
    ]
  },
  {
    "id": "err-visibilityerror",
    "name": "VisibilityError",
    "category": "error",
    "subcategory": "OOP",
    "title": "VisibilityError — Exception Type",
    "summary": "Accessing private member from outside enclosing scope.",
    "criticality": "5 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Accessing private member from outside enclosing scope.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless VisibilityError:\n  display \"Caught VisibilityError\" ?color=#f59e0b",
    "tags": [
      "visibilityerror",
      "error",
      "exception",
      "oop",
      "failure"
    ]
  },
  {
    "id": "err-immutableerror",
    "name": "ImmutableError",
    "category": "error",
    "subcategory": "Storage",
    "title": "ImmutableError — Exception Type",
    "summary": "Attempting to reassign a const variable.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 2",
    "causes": "Attempting to reassign a const variable.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless ImmutableError:\n  display \"Caught ImmutableError\" ?color=#f59e0b",
    "tags": [
      "immutableerror",
      "error",
      "exception",
      "storage",
      "failure"
    ]
  },
  {
    "id": "err-indexoutofboundserror",
    "name": "IndexOutOfBoundsError",
    "category": "error",
    "subcategory": "Array",
    "title": "IndexOutOfBoundsError — Exception Type",
    "summary": "Index exceeds array bounds.",
    "criticality": "5 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Index exceeds array bounds.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless IndexOutOfBoundsError:\n  display \"Caught IndexOutOfBoundsError\" ?color=#f59e0b",
    "tags": [
      "indexoutofboundserror",
      "error",
      "exception",
      "array",
      "failure"
    ]
  },
  {
    "id": "err-entityerror",
    "name": "EntityError",
    "category": "error",
    "subcategory": "Object",
    "title": "EntityError — Exception Type",
    "summary": "Invalid property access or mutation on entity.",
    "criticality": "5 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Invalid property access or mutation on entity.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless EntityError:\n  display \"Caught EntityError\" ?color=#f59e0b",
    "tags": [
      "entityerror",
      "error",
      "exception",
      "object",
      "failure"
    ]
  },
  {
    "id": "err-fileerror",
    "name": "FileError",
    "category": "error",
    "subcategory": "I/O",
    "title": "FileError — Exception Type",
    "summary": "File not found or permission denied during Fs operations.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 2",
    "causes": "File not found or permission denied during Fs operations.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless FileError:\n  display \"Caught FileError\" ?color=#f59e0b",
    "tags": [
      "fileerror",
      "error",
      "exception",
      "i/o",
      "failure"
    ]
  },
  {
    "id": "err-domainerror",
    "name": "DomainError",
    "category": "error",
    "subcategory": "Math",
    "title": "DomainError — Exception Type",
    "summary": "Math function domain violation (e.g. sqrt of negative number).",
    "criticality": "5 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Math function domain violation (e.g. sqrt of negative number).",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless DomainError:\n  display \"Caught DomainError\" ?color=#f59e0b",
    "tags": [
      "domainerror",
      "error",
      "exception",
      "math",
      "failure"
    ]
  },
  {
    "id": "err-asserterror",
    "name": "AssertError",
    "category": "error",
    "subcategory": "Guard",
    "title": "AssertError — Exception Type",
    "summary": "Guard condition or assert evaluated to false.",
    "criticality": "7 / 10",
    "suppressionTier": "Tier 3",
    "causes": "Guard condition or assert evaluated to false.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless AssertError:\n  display \"Caught AssertError\" ?color=#f59e0b",
    "tags": [
      "asserterror",
      "error",
      "exception",
      "guard",
      "failure"
    ]
  },
  {
    "id": "err-unassignedvariableerror",
    "name": "UnassignedVariableError",
    "category": "error",
    "subcategory": "Scope",
    "title": "UnassignedVariableError — Exception Type",
    "summary": "Reading variable declared without initialization.",
    "criticality": "4 / 10",
    "suppressionTier": "Tier 1",
    "causes": "Reading variable declared without initialization.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless UnassignedVariableError:\n  display \"Caught UnassignedVariableError\" ?color=#f59e0b",
    "tags": [
      "unassignedvariableerror",
      "error",
      "exception",
      "scope",
      "failure"
    ]
  },
  {
    "id": "err-asyncerror",
    "name": "AsyncError",
    "category": "error",
    "subcategory": "Concurrency",
    "title": "AsyncError — Exception Type",
    "summary": "Unhandled panic inside async worker fiber.",
    "criticality": "7 / 10",
    "suppressionTier": "Tier 3",
    "causes": "Unhandled panic inside async worker fiber.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless AsyncError:\n  display \"Caught AsyncError\" ?color=#f59e0b",
    "tags": [
      "asyncerror",
      "error",
      "exception",
      "concurrency",
      "failure"
    ]
  },
  {
    "id": "err-channelerror",
    "name": "ChannelError",
    "category": "error",
    "subcategory": "Concurrency",
    "title": "ChannelError — Exception Type",
    "summary": "Writing to closed channel or buffer deadlock.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 2",
    "causes": "Writing to closed channel or buffer deadlock.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless ChannelError:\n  display \"Caught ChannelError\" ?color=#f59e0b",
    "tags": [
      "channelerror",
      "error",
      "exception",
      "concurrency",
      "failure"
    ]
  },
  {
    "id": "err-matcherror",
    "name": "MatchError",
    "category": "error",
    "subcategory": "Control",
    "title": "MatchError — Exception Type",
    "summary": "No match branch satisfied and no default case (_) provided.",
    "criticality": "5 / 10",
    "suppressionTier": "Tier 1",
    "causes": "No match branch satisfied and no default case (_) provided.",
    "remedy": "Use do...unless blocks or validate inputs prior to invocation.",
    "example": "do:\n  ! Risky code\n  display \"Running...\"\nunless MatchError:\n  display \"Caught MatchError\" ?color=#f59e0b",
    "tags": [
      "matcherror",
      "error",
      "exception",
      "control",
      "failure"
    ]
  },
  {
    "id": "err-assertionerror",
    "name": "AssertionError",
    "category": "error",
    "subcategory": "Compiler Exception",
    "title": "AssertionError — Auto-Registered Exception",
    "summary": "Compiler error exception registered in src/main.c.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Triggered by runtime or syntax violation during evaluation.",
    "remedy": "Guard with do...unless AssertionError block or validate inputs.",
    "example": "do:\n  ! Operation\nunless AssertionError:\n  display \"Caught AssertionError\" ?color=#f59e0b",
    "tags": [
      "assertionerror",
      "error",
      "exception"
    ]
  },
  {
    "id": "err-operationerror",
    "name": "OperationError",
    "category": "error",
    "subcategory": "Compiler Exception",
    "title": "OperationError — Auto-Registered Exception",
    "summary": "Compiler error exception registered in src/main.c.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Triggered by runtime or syntax violation during evaluation.",
    "remedy": "Guard with do...unless OperationError block or validate inputs.",
    "example": "do:\n  ! Operation\nunless OperationError:\n  display \"Caught OperationError\" ?color=#f59e0b",
    "tags": [
      "operationerror",
      "error",
      "exception"
    ]
  },
  {
    "id": "err-headermismatcherror",
    "name": "HeaderMismatchError",
    "category": "error",
    "subcategory": "Compiler Exception",
    "title": "HeaderMismatchError — Auto-Registered Exception",
    "summary": "Compiler error exception registered in src/main.c.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Triggered by runtime or syntax violation during evaluation.",
    "remedy": "Guard with do...unless HeaderMismatchError block or validate inputs.",
    "example": "do:\n  ! Operation\nunless HeaderMismatchError:\n  display \"Caught HeaderMismatchError\" ?color=#f59e0b",
    "tags": [
      "headermismatcherror",
      "error",
      "exception"
    ]
  },
  {
    "id": "err-invalidheadererror",
    "name": "InvalidHeaderError",
    "category": "error",
    "subcategory": "Compiler Exception",
    "title": "InvalidHeaderError — Auto-Registered Exception",
    "summary": "Compiler error exception registered in src/main.c.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Triggered by runtime or syntax violation during evaluation.",
    "remedy": "Guard with do...unless InvalidHeaderError block or validate inputs.",
    "example": "do:\n  ! Operation\nunless InvalidHeaderError:\n  display \"Caught InvalidHeaderError\" ?color=#f59e0b",
    "tags": [
      "invalidheadererror",
      "error",
      "exception"
    ]
  },
  {
    "id": "lib-arrays",
    "name": "Arrays",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Arrays — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Arrays.lib.vrs.",
    "syntax": "load Arrays",
    "returns": "Library exports and methods",
    "example": "load Arrays\ndisplay \"Arrays loaded\" ?color=#00FFCC",
    "tags": [
      "arrays",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-assert",
    "name": "Assert",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Assert — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Assert.lib.vrs.",
    "syntax": "load Assert",
    "returns": "Library exports and methods",
    "example": "load Assert\ndisplay \"Assert loaded\" ?color=#00FFCC",
    "tags": [
      "assert",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-benchmark",
    "name": "Benchmark",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Benchmark — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Benchmark.lib.vrs.",
    "syntax": "load Benchmark",
    "returns": "Library exports and methods",
    "example": "load Benchmark\ndisplay \"Benchmark loaded\" ?color=#00FFCC",
    "tags": [
      "benchmark",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-console",
    "name": "Console",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Console — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Console.lib.vrs.",
    "syntax": "load Console",
    "returns": "Library exports and methods",
    "example": "load Console\ndisplay \"Console loaded\" ?color=#00FFCC",
    "tags": [
      "console",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-env",
    "name": "Env",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Env — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Env.lib.vrs.",
    "syntax": "load Env",
    "returns": "Library exports and methods",
    "example": "load Env\ndisplay \"Env loaded\" ?color=#00FFCC",
    "tags": [
      "env",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-log",
    "name": "Log",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Log — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Log.lib.vrs.",
    "syntax": "load Log",
    "returns": "Library exports and methods",
    "example": "load Log\ndisplay \"Log loaded\" ?color=#00FFCC",
    "tags": [
      "log",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-mock",
    "name": "Mock",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Mock — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Mock.lib.vrs.",
    "syntax": "load Mock",
    "returns": "Library exports and methods",
    "example": "load Mock\ndisplay \"Mock loaded\" ?color=#00FFCC",
    "tags": [
      "mock",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-path",
    "name": "Path",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Path — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Path.lib.vrs.",
    "syntax": "load Path",
    "returns": "Library exports and methods",
    "example": "load Path\ndisplay \"Path loaded\" ?color=#00FFCC",
    "tags": [
      "path",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-regex",
    "name": "Regex",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Regex — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Regex.lib.vrs.",
    "syntax": "load Regex",
    "returns": "Library exports and methods",
    "example": "load Regex\ndisplay \"Regex loaded\" ?color=#00FFCC",
    "tags": [
      "regex",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-strings",
    "name": "Strings",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Strings — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Strings.lib.vrs.",
    "syntax": "load Strings",
    "returns": "Library exports and methods",
    "example": "load Strings\ndisplay \"Strings loaded\" ?color=#00FFCC",
    "tags": [
      "strings",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "lib-validate",
    "name": "Validate",
    "category": "library",
    "subcategory": "Standard Library",
    "title": "Validate — Auto-Registered Standard Library",
    "summary": "Standard library module discovered in stdlib/Validate.lib.vrs.",
    "syntax": "load Validate",
    "returns": "Library exports and methods",
    "example": "load Validate\ndisplay \"Validate loaded\" ?color=#00FFCC",
    "tags": [
      "validate",
      "library",
      "stdlib",
      "module"
    ]
  },
  {
    "id": "any",
    "name": "any",
    "category": "datatype",
    "subcategory": "Variant Type",
    "summary": "Unconstrained polymorphic variant type bypassing strict compile-time type validation.",
    "syntax": "set any <name> : <value>",
    "details": "The `any` datatype allows a variable to hold any value (num, str, bool, arr, entity) and be dynamically reassigned to other types at runtime without triggering a DataTypeError.",
    "parameters": [
      {
        "name": "value",
        "type": "any expression",
        "description": "Any valid VerScript expression."
      }
    ],
    "return_type": "any",
    "paired_keywords": [
      "DataType",
      "as",
      "set"
    ],
    "example": "set any dynamicVal : 42\nset dynamicVal : \"Now I am a string\"\ndisplay dynamicVal",
    "tags": [
      "any",
      "variant",
      "dynamic",
      "unconstrained",
      "datatype",
      "polymorphic"
    ]
  },
  {
    "id": "void",
    "name": "void",
    "category": "datatype",
    "subcategory": "Function Signatures",
    "summary": "Designates that a routine performs side-effects and returns no meaningful value.",
    "syntax": "def func <name>(<params>) -> void:\n  <body>",
    "details": "Used primarily in header contract files (*.h.vrs) and explicit function signatures to indicate procedure calls that reply nothing.",
    "parameters": [],
    "return_type": "void",
    "paired_keywords": [
      "def",
      "func",
      "reply",
      "header"
    ],
    "example": "header LoggerContract:\n  def func logMessage(msg: str) -> void\n\ninclude \"LoggerContract.h.vrs\"",
    "tags": [
      "void",
      "none",
      "empty",
      "signature",
      "datatype",
      "return"
    ]
  },
  {
    "id": "nil",
    "name": "nil",
    "category": "datatype",
    "subcategory": "Literals",
    "summary": "Represents the intentional absence of any value or uninitialized object reference.",
    "syntax": "set <name> : nil\nif <name> == nil then: ...",
    "details": "`nil` (or `null`) represents null pointers and absent values. Safe navigation `?.` and nullish coalescing `??` operators are designed specifically to handle `nil` references safely.",
    "parameters": [],
    "return_type": "nil",
    "paired_keywords": [
      "null",
      "??",
      "?.",
      "if"
    ],
    "example": "set user : nil\nset name : user?.name ?? \"Anonymous\"\ndisplay name",
    "tags": [
      "nil",
      "null",
      "absent",
      "empty",
      "datatype",
      "optional"
    ]
  },
  {
    "id": "header",
    "name": "header",
    "category": "keyword",
    "subcategory": "Header Contracts",
    "summary": "Defines an interface contract specification declaring prototypes and type constraints in *.h.vrs files.",
    "syntax": "header <ContractName>:\n  def func <routineName>(<params>): <return_type>\n  struct <StructName>:\n    <field> : <type>",
    "details": "Header specifications enforce compile-time and runtime contracts between callers and implementations. Companion headers (<file>.h.vrs) are automatically detected and verified against implementations (<file>.vrs).",
    "parameters": [
      {
        "name": "ContractName",
        "type": "identifier",
        "description": "Name of the header specification block."
      }
    ],
    "return_type": "Contract Definition",
    "paired_keywords": [
      "include",
      "contract",
      "require",
      "ensure",
      "struct",
      "def"
    ],
    "example": "header MathSpec:\n  def func add(a: num, b: num): num\n  def func mul(a: num, b: num): num",
    "tags": [
      "header",
      "contract",
      "interface",
      "prototype",
      "specification",
      "h.vrs"
    ]
  },
  {
    "id": "contract",
    "name": "contract",
    "category": "keyword",
    "subcategory": "Header Contracts",
    "summary": "Declares an invariant behavioral specification for functions, structs, or libraries.",
    "syntax": "contract <Name>:\n  require: <precondition>\n  ensure: <postcondition>",
    "details": "Enforces Design by Contract (DbC). Contracts guarantee preconditions before routines execute and postconditions after return.",
    "parameters": [
      {
        "name": "Name",
        "type": "identifier",
        "description": "Name of the contract specification."
      }
    ],
    "return_type": "Contract Block",
    "paired_keywords": [
      "header",
      "require",
      "ensure",
      "inbound",
      "outbound"
    ],
    "example": "contract SafeDivision:\n  require: denominator != 0\n  ensure: it != nil",
    "tags": [
      "contract",
      "dbc",
      "invariant",
      "precondition",
      "postcondition",
      "header"
    ]
  },
  {
    "id": "require",
    "name": "require",
    "category": "keyword",
    "subcategory": "Header Contracts",
    "summary": "Specifies a precondition predicate that must evaluate to true prior to executing a routine.",
    "syntax": "require: <boolean_condition>",
    "details": "If the `require` predicate evaluates to false or 0 upon entering a routine, the runtime immediately throws a `PreconditionViolationError`.",
    "parameters": [
      {
        "name": "condition",
        "type": "bool",
        "description": "Precondition assertion expression."
      }
    ],
    "return_type": "void",
    "paired_keywords": [
      "ensure",
      "contract",
      "header",
      "inbound"
    ],
    "example": "def func withdraw(amount: num):\n  require: amount > 0 && amount <= this.balance\n  set this.balance : this.balance - amount",
    "tags": [
      "require",
      "precondition",
      "contract",
      "assertion",
      "guard",
      "header"
    ]
  },
  {
    "id": "ensure",
    "name": "ensure",
    "category": "keyword",
    "subcategory": "Header Contracts",
    "summary": "Specifies a postcondition predicate that must evaluate to true after routine completion before returning to caller.",
    "syntax": "ensure: <boolean_condition_using_it>",
    "details": "Validates return values (accessible via `it`) and state postconditions. A false condition raises `PostconditionViolationError`.",
    "parameters": [
      {
        "name": "condition",
        "type": "bool expression using it",
        "description": "Postcondition assertion predicate."
      }
    ],
    "return_type": "void",
    "paired_keywords": [
      "require",
      "contract",
      "header",
      "outbound",
      "it"
    ],
    "example": "def func abs(x: num):\n  ensure: it >= 0\n  if x < 0 then: reply -x else: reply x",
    "tags": [
      "ensure",
      "postcondition",
      "contract",
      "assertion",
      "it",
      "header"
    ]
  },
  {
    "id": "include",
    "name": "include",
    "category": "keyword",
    "subcategory": "Header Contracts",
    "summary": "Explicitly imports and binds an external *.h.vrs header contract specification into the current compilation unit.",
    "syntax": "include \"<path_to_header>.h.vrs\"",
    "details": "Loads header prototypes and validates all function implementations against declared signatures.",
    "parameters": [
      {
        "name": "headerPath",
        "type": "string",
        "description": "Relative or absolute file path to the *.h.vrs file."
      }
    ],
    "return_type": "void",
    "paired_keywords": [
      "header",
      "contract",
      "import",
      "load"
    ],
    "example": "include \"math_contract.h.vrs\"\n\ndef func add(a: num, b: num):\n  reply a + b",
    "tags": [
      "include",
      "header",
      "contract",
      "import",
      "prototype",
      "h.vrs"
    ]
  },
  {
    "id": "op_plus",
    "name": "+ (Addition / Concat)",
    "category": "operator",
    "subcategory": "Arithmetic & Strings",
    "summary": "Adds numeric values, concatenates strings, or appends elements to arrays.",
    "syntax": "<a> + <b>",
    "details": "Polymorphic operator: (1) Numeric addition: 5 + 3 = 8, (2) String concatenation: \"Hello \" + \"World\", (3) Array union: [1, 2] + [3, 4].",
    "parameters": [
      {
        "name": "a",
        "type": "num | str | arr",
        "description": "Left operand."
      },
      {
        "name": "b",
        "type": "num | str | arr",
        "description": "Right operand."
      }
    ],
    "return_type": "num | str | arr",
    "paired_keywords": [
      "-",
      "*",
      "/",
      "%"
    ],
    "example": "set n : 10 + 25\nset msg : \"Total count: \" + n\ndisplay msg",
    "tags": [
      "+",
      "plus",
      "add",
      "addition",
      "concat",
      "concatenation",
      "operator"
    ]
  },
  {
    "id": "op_minus",
    "name": "- (Subtraction / Negation)",
    "category": "operator",
    "subcategory": "Arithmetic",
    "summary": "Subtracts the right numeric operand from the left operand, or negates a numeric expression as unary minus.",
    "syntax": "<a> - <b>\n-<expression>",
    "details": "Binary subtraction (e.g. 10 - 4 = 6) and unary negation (e.g. -x).",
    "parameters": [
      {
        "name": "a",
        "type": "num",
        "description": "Minuend."
      },
      {
        "name": "b",
        "type": "num",
        "description": "Subtrahend."
      }
    ],
    "return_type": "num",
    "paired_keywords": [
      "+",
      "*",
      "/"
    ],
    "example": "set diff : 100 - 35\nset inv : -diff\ndisplay inv",
    "tags": [
      "-",
      "minus",
      "subtract",
      "subtraction",
      "negation",
      "operator"
    ]
  },
  {
    "id": "op_multiply",
    "name": "* (Multiplication)",
    "category": "operator",
    "subcategory": "Arithmetic",
    "summary": "Multiplies two numeric factors, or repeats a string/array by an integer factor.",
    "syntax": "<a> * <b>",
    "details": "Performs arithmetic multiplication: 6 * 7 = 42. When used with strings and numbers (\"=\" * 10), generates repeating sequences.",
    "parameters": [
      {
        "name": "a",
        "type": "num | str",
        "description": "Left multiplicand."
      },
      {
        "name": "b",
        "type": "num",
        "description": "Right multiplicand."
      }
    ],
    "return_type": "num | str",
    "paired_keywords": [
      "/",
      "+",
      "-"
    ],
    "example": "set area : width * height\nset line : \"=\" * 20\ndisplay line",
    "tags": [
      "*",
      "multiply",
      "multiplication",
      "times",
      "product",
      "operator"
    ]
  },
  {
    "id": "op_divide",
    "name": "/ (Division)",
    "category": "operator",
    "subcategory": "Arithmetic",
    "summary": "Divides the left numeric operand by the right operand. Throws DivisionByZeroError if denominator is 0.",
    "syntax": "<a> / <b>",
    "details": "Floating point division. Automatically throws `DivisionByZeroError` if the denominator equals 0.",
    "parameters": [
      {
        "name": "a",
        "type": "num",
        "description": "Dividend."
      },
      {
        "name": "b",
        "type": "num (non-zero)",
        "description": "Divisor."
      }
    ],
    "return_type": "num",
    "paired_keywords": [
      "%",
      "*",
      "+"
    ],
    "example": "set ratio : 100 / 4\ndisplay \"Ratio: \" + ratio",
    "tags": [
      "/",
      "divide",
      "division",
      "slash",
      "quotient",
      "operator"
    ]
  },
  {
    "id": "op_modulo",
    "name": "% (Modulo)",
    "category": "operator",
    "subcategory": "Arithmetic",
    "summary": "Calculates the integer or floating-point remainder of dividing two numbers.",
    "syntax": "<a> % <b>",
    "details": "Computes remainder after division (e.g. 10 % 3 = 1). Essential for parity checks and circular buffer wrapping.",
    "parameters": [
      {
        "name": "a",
        "type": "num",
        "description": "Dividend."
      },
      {
        "name": "b",
        "type": "num",
        "description": "Divisor."
      }
    ],
    "return_type": "num",
    "paired_keywords": [
      "/",
      "Math"
    ],
    "example": "if count % 2 == 0 then:\n  display \"Even number\"\nelse:\n  display \"Odd number\"",
    "tags": [
      "%",
      "modulo",
      "mod",
      "remainder",
      "operator"
    ]
  },
  {
    "id": "op_eq",
    "name": "== (Equality)",
    "category": "operator",
    "subcategory": "Comparison",
    "summary": "Tests whether two expressions have equal values across numbers, strings, booleans, and arrays.",
    "syntax": "<a> == <b>",
    "details": "Returns true if values are identical; supports structural comparison of strings and numbers.",
    "parameters": [
      {
        "name": "a",
        "type": "any",
        "description": "Left operand."
      },
      {
        "name": "b",
        "type": "any",
        "description": "Right operand."
      }
    ],
    "return_type": "bool",
    "paired_keywords": [
      "!=",
      "<",
      ">",
      "<=",
      ">="
    ],
    "example": "if status == \"ready\" then:\n  display \"Proceeding\"",
    "tags": [
      "==",
      "equality",
      "equals",
      "compare",
      "comparison",
      "operator"
    ]
  },
  {
    "id": "op_neq",
    "name": "!= (Inequality)",
    "category": "operator",
    "subcategory": "Comparison",
    "summary": "Tests whether two expressions evaluate to different values.",
    "syntax": "<a> != <b>",
    "details": "Inverted equality test. Returns true when `a` is not equal to `b`.",
    "parameters": [
      {
        "name": "a",
        "type": "any",
        "description": "Left operand."
      },
      {
        "name": "b",
        "type": "any",
        "description": "Right operand."
      }
    ],
    "return_type": "bool",
    "paired_keywords": [
      "==",
      "!",
      "if"
    ],
    "example": "if token != nil then:\n  display \"Authenticated\"",
    "tags": [
      "!=",
      "inequality",
      "not equal",
      "compare",
      "operator"
    ]
  },
  {
    "id": "op_relational",
    "name": "<, >, <=, >= (Relational)",
    "category": "operator",
    "subcategory": "Comparison",
    "summary": "Ordered relational comparisons: less than (<), greater than (>), less/equal (<=), greater/equal (>=).",
    "syntax": "<a> < <b>\n<a> > <b>\n<a> <= <b>\n<a> >= <b>",
    "details": "Evaluates numerical order and lexicographical string order.",
    "parameters": [
      {
        "name": "a",
        "type": "num | str",
        "description": "Left operand."
      },
      {
        "name": "b",
        "type": "num | str",
        "description": "Right operand."
      }
    ],
    "return_type": "bool",
    "paired_keywords": [
      "==",
      "!=",
      "if",
      "while"
    ],
    "example": "if age >= 18 then:\n  display \"Adult\"",
    "tags": [
      "<",
      ">",
      "<=",
      ">=",
      "relational",
      "comparison",
      "order",
      "operator"
    ]
  },
  {
    "id": "op_and",
    "name": "&& (Logical AND)",
    "category": "operator",
    "subcategory": "Logical",
    "summary": "Short-circuiting logical conjunction. Evaluates to true only if both operands are truthy.",
    "syntax": "<a> && <b>",
    "details": "If `a` evaluates to false, `b` is short-circuited and not evaluated.",
    "parameters": [
      {
        "name": "a",
        "type": "bool",
        "description": "First condition."
      },
      {
        "name": "b",
        "type": "bool",
        "description": "Second condition."
      }
    ],
    "return_type": "bool",
    "paired_keywords": [
      "||",
      "!",
      "if"
    ],
    "example": "if user.isLoggedIn && user.hasPermission then:\n  display \"Access Granted\"",
    "tags": [
      "&&",
      "and",
      "logical and",
      "boolean",
      "operator"
    ]
  },
  {
    "id": "op_or",
    "name": "|| (Logical OR)",
    "category": "operator",
    "subcategory": "Logical",
    "summary": "Short-circuiting logical disjunction. Evaluates to true if either operand is truthy.",
    "syntax": "<a> || <b>",
    "details": "If `a` is true, returns true immediately without evaluating `b`.",
    "parameters": [
      {
        "name": "a",
        "type": "bool",
        "description": "First condition."
      },
      {
        "name": "b",
        "type": "bool",
        "description": "Second condition."
      }
    ],
    "return_type": "bool",
    "paired_keywords": [
      "&&",
      "!",
      "if"
    ],
    "example": "if cache.exists || fetchRemote() then:\n  display \"Data ready\"",
    "tags": [
      "||",
      "or",
      "logical or",
      "boolean",
      "operator"
    ]
  },
  {
    "id": "op_not",
    "name": "! (Logical NOT / Comment Prefix)",
    "category": "operator",
    "subcategory": "Logical & Comments",
    "summary": "Logical negation operator in expressions (!expr); also line comment prefix when starting a line (! comment).",
    "syntax": "!<expression>\n! Single line comment",
    "details": "Dual functionality in VerScript: (1) Inside expressions: inverts boolean truthiness (!true == false), (2) At start of line: denotes a line comment.",
    "parameters": [
      {
        "name": "expr",
        "type": "bool or expression",
        "description": "Expression to negate."
      }
    ],
    "return_type": "bool",
    "paired_keywords": [
      "&&",
      "||",
      "unless"
    ],
    "example": "! This is a VerScript comment line\nset bool flag : false\nif !flag then:\n  display \"Flag was false\"",
    "tags": [
      "!",
      "not",
      "negation",
      "comment",
      "invert",
      "operator"
    ]
  },
  {
    "id": "op_safe_nav",
    "name": "?. (Safe Navigation)",
    "category": "operator",
    "subcategory": "Member Access",
    "summary": "Safe property or method navigation; returns nil without throwing an error if the receiver is nil.",
    "syntax": "<receiver>?.<property>\n<receiver>?.<method>(<args>)",
    "details": "Prevents NullPointer / UndefinedVariable errors when traversing deeply nested optional structures.",
    "parameters": [
      {
        "name": "receiver",
        "type": "entity | object | nil",
        "description": "Object to traverse."
      }
    ],
    "return_type": "any or nil",
    "paired_keywords": [
      "??",
      "nil",
      "."
    ],
    "example": "set city : user?.profile?.address?.city ?? \"Unknown City\"\ndisplay city",
    "tags": [
      "?.",
      "safe navigation",
      "optional chaining",
      "nil safe",
      "operator"
    ]
  },
  {
    "id": "op_null_coalesce",
    "name": "?? (Nullish Coalescing)",
    "category": "operator",
    "subcategory": "Fallbacks",
    "summary": "Returns the right-hand operand if the left operand is nil or empty, otherwise returns the left operand.",
    "syntax": "<expr> ?? <default_value>",
    "details": "Provides a robust fallback mechanism for optional or uninitialized variables.",
    "parameters": [
      {
        "name": "expr",
        "type": "any",
        "description": "Primary value."
      },
      {
        "name": "default_value",
        "type": "any",
        "description": "Fallback value if expr is nil."
      }
    ],
    "return_type": "any",
    "paired_keywords": [
      "?.",
      "nil",
      "set"
    ],
    "example": "set port : config.port ?? 8080\ndisplay \"Running on port: \" + port",
    "tags": [
      "??",
      "coalescing",
      "nullish",
      "default",
      "fallback",
      "operator"
    ]
  },
  {
    "id": "op_colon",
    "name": ": (Assignment & Block Colon)",
    "category": "operator",
    "subcategory": "Syntax & Assignment",
    "summary": "Binds values to variables (set x: 42) and marks indented block headers (if cond:, loop 5:).",
    "syntax": "set <var> : <value>\n<keyword> <condition>:\n  <indented_body>",
    "details": "The fundamental syntactic pillar of VerScript: (1) Replaces the equal sign `=` for variable assignments, (2) Introduces Python-style indented blocks.",
    "parameters": [],
    "return_type": "void",
    "paired_keywords": [
      "set",
      "def",
      "if",
      "while",
      "class",
      "lib"
    ],
    "example": "set x : 100\nif x > 50:\n  display \"Greater than 50\"",
    "tags": [
      ":",
      "colon",
      "assignment",
      "block",
      "bind",
      "syntax",
      "operator"
    ]
  },
  {
    "id": "op_question_flag",
    "name": "? (Directive / Flag Marker)",
    "category": "operator",
    "subcategory": "Directives & Flags",
    "summary": "Prefixes modifier flags and inline parameters on statements (e.g. ?color=cyan, ?default=25, ?override).",
    "syntax": "display <msg> ?color=<name> ?bold\nprompt <var> ?default=<val>",
    "details": "VerScript statements support inline keyword options prefixed by `?` to configure visual formatting or execution flags.",
    "parameters": [],
    "return_type": "void",
    "paired_keywords": [
      "display",
      "prompt",
      "meta",
      "pragma"
    ],
    "example": "display \"Success!\" ?color=green ?bold\nprompt username ?default=\"Guest\"",
    "tags": [
      "?",
      "directive",
      "flag",
      "modifier",
      "color",
      "options",
      "operator"
    ]
  },
  {
    "id": "op_dot",
    "name": ". (Member Access)",
    "category": "operator",
    "subcategory": "Member Access",
    "summary": "Accesses a property or invokes a method on an entity, library, string, or array instance.",
    "syntax": "<object>.<member>",
    "details": "Standard dot-operator notation for object-oriented dispatch, library routine calls (Matrix.det), and property reading.",
    "parameters": [
      {
        "name": "object",
        "type": "entity | lib | str | arr",
        "description": "Receiver instance."
      },
      {
        "name": "member",
        "type": "identifier",
        "description": "Property or method name."
      }
    ],
    "return_type": "any",
    "paired_keywords": [
      "?.",
      "this",
      "class",
      "lib"
    ],
    "example": "load Math\nset radius : 5\nset circ : 2 * Math.PI * radius",
    "tags": [
      ".",
      "dot",
      "member",
      "method",
      "property",
      "call",
      "operator"
    ]
  },
  {
    "id": "construct",
    "name": "construct",
    "category": "keyword",
    "subcategory": "Object Orientation",
    "summary": "Constructor block or routine automatically invoked when instantiating a class or library entity.",
    "syntax": "class <Name> <arg1> <arg2>:\n  construct:\n    set this.<field1> : <arg1>\n    set this.<field2> : <arg2>\n\nlib <LibName> <arg1>:\n  construct:\n    ...",
    "details": "The constructor initializes an entity's dynamic state upon creation. Parameters passed into `MyClass(a, b)` or `MyLib(a, b)` are bound in scope and available to initialize `this` properties. Constructors require no arguments of their own because class/lib arguments are attached directly to the definition.",
    "parameters": [
      {
        "name": "this properties",
        "type": "assignments",
        "description": "Initialization statements setting this.<prop> fields."
      }
    ],
    "return_type": "Entity Instance",
    "paired_keywords": [
      "class",
      "lib",
      "this",
      "inst",
      "set"
    ],
    "example": "class Vector2D x y:\n  construct:\n    set this.x : x\n    set this.y : y\n  def func magnitude:\n    reply Math.sqrt(this.x * this.x + this.y * this.y)\n\nset v : Vector2D(3, 4)\ndisplay v.magnitude()  ! 5",
    "tags": [
      "construct",
      "constructor",
      "init",
      "create",
      "class",
      "lib",
      "oop"
    ]
  },
  {
    "id": "this",
    "name": "this",
    "category": "keyword",
    "subcategory": "Object Orientation",
    "summary": "Implicit reference to the current entity instance executing a method or constructor.",
    "syntax": "this.<property>\nthis.<method>()",
    "details": "Within `class` and `lib` methods and constructors, `this` binds to the active instance state and dynamic member variables.",
    "parameters": [],
    "return_type": "entity",
    "paired_keywords": [
      "class",
      "lib",
      "construct",
      "thisstatic"
    ],
    "example": "class Counter:\n  construct:\n    set this.val : 0\n  def func inc:\n    set this.val : this.val + 1",
    "tags": [
      "this",
      "self",
      "instance",
      "current",
      "oop",
      "keyword"
    ]
  },
  {
    "id": "matrix_class",
    "name": "Matrix (Constructor & Class)",
    "category": "library",
    "subcategory": "Matrix Math",
    "summary": "Linear algebra library and matrix class supporting constructors, determinants, matrix multiplication, inversion, and decomposition.",
    "syntax": "load Matrix\nset m : Matrix(rows, cols, defaultValue)\nMatrix.det(m)\nMatrix.identity(n)",
    "details": "`Matrix` can be used statically (`Matrix.multiply(A, B)`) or instantiated as an entity (`set m : Matrix(3, 3, 0); m.det()`).",
    "parameters": [
      {
        "name": "rows",
        "type": "num",
        "description": "Number of rows."
      },
      {
        "name": "cols",
        "type": "num",
        "description": "Number of columns."
      },
      {
        "name": "defaultVal",
        "type": "num",
        "description": "Optional initial element value (default 0)."
      }
    ],
    "return_type": "Matrix entity or 2D Array",
    "paired_keywords": [
      "load",
      "Vector",
      "Math",
      "construct"
    ],
    "example": "load Matrix\nset m : Matrix.identity(3)\ndisplay \"Determinant: \" + Matrix.det(m)",
    "tags": [
      "matrix",
      "det",
      "determinant",
      "identity",
      "inverse",
      "linear-algebra",
      "math",
      "library"
    ]
  },
  {
    "id": "vector_class",
    "name": "Vector (Constructor & Class)",
    "category": "library",
    "subcategory": "Vector Math",
    "summary": "2D, 3D, and n-dimensional geometric vector library and class (dot product, cross product, magnitude, normalize).",
    "syntax": "load Vector\nset v : Vector(x, y, z)\nv.magnitude()\nVector.dot(v1, v2)",
    "details": "Provides high-speed vector arithmetic. Supports instance method calls (`v.magnitude()`) as well as static library functions (`Vector.cross(u, v)`).",
    "parameters": [
      {
        "name": "x",
        "type": "num",
        "description": "X component."
      },
      {
        "name": "y",
        "type": "num",
        "description": "Y component."
      },
      {
        "name": "z",
        "type": "num",
        "description": "Optional Z component (default 0)."
      }
    ],
    "return_type": "Vector entity",
    "paired_keywords": [
      "load",
      "Matrix",
      "Math",
      "construct"
    ],
    "example": "load Vector\nset v1 : Vector(1, 0, 0)\nset v2 : Vector(0, 1, 0)\nset v3 : Vector.cross(v1, v2)\ndisplay v3.z  ! 1",
    "tags": [
      "vector",
      "dot",
      "cross",
      "magnitude",
      "norm",
      "physics",
      "geometry",
      "library"
    ]
  },
  {
    "id": "json_methods",
    "name": "Json.parse / Json.stringify",
    "category": "library",
    "subcategory": "Serialization",
    "summary": "Parses JSON text into VerScript entities and arrays, or serializes data into formatted JSON strings.",
    "syntax": "load Json\nset data : Json.parse(jsonString)\nset text : Json.stringify(data)",
    "details": "Standard JSON parser and serializer with support for nested arrays, dictionaries, numbers, and escape characters.",
    "parameters": [
      {
        "name": "input",
        "type": "str or entity",
        "description": "JSON string to parse, or entity to serialize."
      }
    ],
    "return_type": "entity | arr | str",
    "paired_keywords": [
      "load",
      "Fs",
      "Http",
      "str"
    ],
    "example": "load Json\nset obj : Json.parse('{\"name\": \"VerScript\", \"version\": 2}')\ndisplay obj.name",
    "tags": [
      "json",
      "parse",
      "stringify",
      "serialization",
      "dict",
      "library"
    ]
  },
  {
    "id": "fs_methods",
    "name": "Fs.readFile / Fs.writeFile",
    "category": "library",
    "subcategory": "Filesystem",
    "summary": "Reads, writes, and manages files and directories on the local host filesystem.",
    "syntax": "load Fs\nset content : Fs.readFile(\"data.txt\")\nFs.writeFile(\"output.txt\", content)\nFs.exists(\"data.txt\")",
    "details": "Provides direct filesystem access. Automatically handles file descriptors, binary buffers, and text encodings.",
    "parameters": [
      {
        "name": "path",
        "type": "str",
        "description": "Filesystem path."
      },
      {
        "name": "content",
        "type": "str",
        "description": "Data to write."
      }
    ],
    "return_type": "str or bool",
    "paired_keywords": [
      "load",
      "Path",
      "Sys"
    ],
    "example": "load Fs\nif Fs.exists(\"config.vrs\") then:\n  set cfg : Fs.readFile(\"config.vrs\")",
    "tags": [
      "fs",
      "file",
      "readfile",
      "writefile",
      "io",
      "filesystem",
      "library"
    ]
  },
  {
    "id": "err-outputtypeerror",
    "name": "OutputTypeError",
    "category": "error",
    "subcategory": "Compiler Exception",
    "title": "OutputTypeError — Auto-Registered Exception",
    "summary": "Compiler error exception registered in src/main.c.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Triggered by runtime or syntax violation during evaluation.",
    "remedy": "Guard with do...unless OutputTypeError block or validate inputs.",
    "example": "do:\n  ! Operation\nunless OutputTypeError:\n  display \"Caught OutputTypeError\" ?color=#f59e0b",
    "tags": [
      "outputtypeerror",
      "error",
      "exception"
    ]
  },
  {
    "id": "err-outputtypemissingerror",
    "name": "OutputTypeMissingError",
    "category": "error",
    "subcategory": "Compiler Exception",
    "title": "OutputTypeMissingError — Auto-Registered Exception",
    "summary": "Compiler error exception registered in src/main.c.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Triggered by runtime or syntax violation during evaluation.",
    "remedy": "Guard with do...unless OutputTypeMissingError block or validate inputs.",
    "example": "do:\n  ! Operation\nunless OutputTypeMissingError:\n  display \"Caught OutputTypeMissingError\" ?color=#f59e0b",
    "tags": [
      "outputtypemissingerror",
      "error",
      "exception"
    ]
  },
  {
    "id": "err-outputexistenceerror",
    "name": "OutputExistenceError",
    "category": "error",
    "subcategory": "Compiler Exception",
    "title": "OutputExistenceError — Auto-Registered Exception",
    "summary": "Compiler error exception registered in src/main.c.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Triggered by runtime or syntax violation during evaluation.",
    "remedy": "Guard with do...unless OutputExistenceError block or validate inputs.",
    "example": "do:\n  ! Operation\nunless OutputExistenceError:\n  display \"Caught OutputExistenceError\" ?color=#f59e0b",
    "tags": [
      "outputexistenceerror",
      "error",
      "exception"
    ]
  },
  {
    "id": "err-complexmatherror",
    "name": "ComplexMathError",
    "category": "error",
    "subcategory": "Compiler Exception",
    "title": "ComplexMathError — Auto-Registered Exception",
    "summary": "Compiler error exception registered in src/main.c.",
    "criticality": "6 / 10",
    "suppressionTier": "Tier 1 (SuppressErrors compatible)",
    "causes": "Triggered by runtime or syntax violation during evaluation.",
    "remedy": "Guard with do...unless ComplexMathError block or validate inputs.",
    "example": "do:\n  ! Operation\nunless ComplexMathError:\n  display \"Caught ComplexMathError\" ?color=#f59e0b",
    "tags": [
      "complexmatherror",
      "error",
      "exception"
    ]
  },
  {
    "id": "kw-and",
    "name": "and",
    "category": "keyword",
    "subcategory": "Logical Operator",
    "title": "and — Short-Circuit Logical Conjunction",
    "summary": "Evaluates whether two boolean expressions are both true, short-circuiting evaluation if the left operand is false.",
    "syntax": "exprA and exprB",
    "parameters": "exprA (bool), exprB (bool)",
    "returns": "bool (true if both operands evaluate to true)",
    "pairedWith": "if, while, guard, not, or",
    "example": "isValid : true\nisAdmin : true\nif isValid and isAdmin:\n    display \"Access Granted\" ?color=#00FFCC",
    "tags": [
      "and",
      "logic",
      "boolean",
      "conditional"
    ]
  },
  {
    "id": "kw-or",
    "name": "or",
    "category": "keyword",
    "subcategory": "Logical Operator",
    "title": "or — Short-Circuit Logical Disjunction",
    "summary": "Evaluates whether at least one of two boolean expressions is true, short-circuiting if the left operand is true.",
    "syntax": "exprA or exprB",
    "parameters": "exprA (bool), exprB (bool)",
    "returns": "bool (true if either operand is true)",
    "pairedWith": "if, while, guard, and, not",
    "example": "isOwner : false\nisModerator : true\nif isOwner or isModerator:\n    display \"Action Allowed\" ?color=#00FFCC",
    "tags": [
      "or",
      "logic",
      "boolean",
      "conditional"
    ]
  },
  {
    "id": "kw-not",
    "name": "not",
    "category": "keyword",
    "subcategory": "Logical Operator",
    "title": "not — Unary Logical Inversion",
    "summary": "Inverts the truth value of a boolean expression.",
    "syntax": "not expr",
    "parameters": "expr (bool)",
    "returns": "bool (inverted boolean value)",
    "pairedWith": "if, unless, and, or",
    "example": "isReady : false\nif not isReady:\n    display \"System warming up...\" ?color=#f59e0b",
    "tags": [
      "not",
      "logic",
      "boolean",
      "negation"
    ]
  },
  {
    "id": "kw-nand",
    "name": "nand",
    "category": "keyword",
    "subcategory": "Logical Operator",
    "title": "nand — Negated Logical AND Gate",
    "summary": "Returns false only when both operands are true; otherwise returns true.",
    "syntax": "exprA nand exprB",
    "parameters": "exprA (bool), exprB (bool)",
    "returns": "bool",
    "pairedWith": "if, nor, xor",
    "example": "flagA : true\nflagB : true\nresult : flagA nand flagB\ndisplay \"NAND Result: \" + result  ! Displays false",
    "tags": [
      "nand",
      "logic",
      "gate",
      "boolean"
    ]
  },
  {
    "id": "kw-nor",
    "name": "nor",
    "category": "keyword",
    "subcategory": "Logical Operator",
    "title": "nor — Negated Logical OR Gate",
    "summary": "Returns true only when both operands are false; otherwise returns false.",
    "syntax": "exprA nor exprB",
    "parameters": "exprA (bool), exprB (bool)",
    "returns": "bool",
    "pairedWith": "if, nand, xor",
    "example": "a : false\nb : false\nif a nor b:\n    display \"Both are inactive\" ?color=#38bdf8",
    "tags": [
      "nor",
      "logic",
      "gate",
      "boolean"
    ]
  },
  {
    "id": "kw-xor",
    "name": "xor",
    "category": "keyword",
    "subcategory": "Logical Operator",
    "title": "xor — Exclusive Disjunction",
    "summary": "Returns true if exactly one operand is true and the other is false.",
    "syntax": "exprA xor exprB",
    "parameters": "exprA (bool), exprB (bool)",
    "returns": "bool",
    "pairedWith": "xnor, and, or",
    "example": "hasCoupon : true\nhasDiscount : false\nif hasCoupon xor hasDiscount:\n    display \"Valid single promotion\" ?color=#10b981",
    "tags": [
      "xor",
      "logic",
      "exclusive",
      "boolean"
    ]
  },
  {
    "id": "kw-xnor",
    "name": "xnor",
    "category": "keyword",
    "subcategory": "Logical Operator",
    "title": "xnor — Logical Equivalence / Negated XOR",
    "summary": "Returns true if both operands have identical boolean truth values.",
    "syntax": "exprA xnor exprB",
    "parameters": "exprA (bool), exprB (bool)",
    "returns": "bool",
    "pairedWith": "xor, and, or",
    "example": "stateA : true\nstateB : true\nif stateA xnor stateB:\n    display \"States are synchronized\" ?color=#00FFCC",
    "tags": [
      "xnor",
      "logic",
      "equivalence",
      "boolean"
    ]
  },
  {
    "id": "kw-xand",
    "name": "xand",
    "category": "keyword",
    "subcategory": "Logical Operator",
    "title": "xand — Cross Logical Conjunction",
    "summary": "Specialized non-associative logical conjunction operator for strict truth state validation.",
    "syntax": "exprA xand exprB",
    "parameters": "exprA (bool), exprB (bool)",
    "returns": "bool",
    "pairedWith": "and, nand",
    "example": "cond1 : true\ncond2 : true\nres : cond1 xand cond2\ndisplay \"XAND: \" + res",
    "tags": [
      "xand",
      "logic",
      "strict",
      "boolean"
    ]
  },
  {
    "id": "kw-true",
    "name": "true",
    "category": "keyword",
    "subcategory": "Boolean Literal",
    "title": "true — Canonical Boolean Truth Value",
    "summary": "Represents the standard boolean true constant in expressions and logical evaluations.",
    "syntax": "true",
    "parameters": "None",
    "returns": "bool",
    "pairedWith": "false, bool, if",
    "example": "isActive : true\ndisplay \"System active: \" + isActive",
    "tags": [
      "true",
      "boolean",
      "literal",
      "constant"
    ]
  },
  {
    "id": "kw-false",
    "name": "false",
    "category": "keyword",
    "subcategory": "Boolean Literal",
    "title": "false — Canonical Boolean Falsity Value",
    "summary": "Represents the standard boolean false constant in expressions and logical evaluations.",
    "syntax": "false",
    "parameters": "None",
    "returns": "bool",
    "pairedWith": "true, bool, if",
    "example": "isPaused : false\ndisplay \"Paused: \" + isPaused",
    "tags": [
      "false",
      "boolean",
      "literal",
      "constant"
    ]
  },
  {
    "id": "kw-then",
    "name": "then",
    "category": "keyword",
    "subcategory": "Conditional Clause",
    "title": "then — Consequent Conditional Action",
    "summary": "Specifies the immediate execution statement following an if condition on the same line.",
    "syntax": "if condition then statement",
    "parameters": "condition (bool), statement (action)",
    "returns": "Statement result",
    "pairedWith": "if, else",
    "example": "score : 95\nif score >= 90 then display \"Honor Roll!\" ?color=#00FFCC",
    "tags": [
      "then",
      "control",
      "conditional",
      "if"
    ]
  },
  {
    "id": "kw-else",
    "name": "else",
    "category": "keyword",
    "subcategory": "Branching Clause",
    "title": "else — Alternative Execution Branch",
    "summary": "Executes an alternate block of code when an preceding if or unless condition is not satisfied.",
    "syntax": "if condition:\n    ...\nelse:\n    ...",
    "parameters": "None",
    "returns": "None",
    "pairedWith": "if, then, unless",
    "example": "level : 5\nif level > 10:\n    display \"Veteran\"\nelse:\n    display \"Novice\" ?color=#f59e0b",
    "tags": [
      "else",
      "control",
      "conditional",
      "branch"
    ]
  },
  {
    "id": "kw-with",
    "name": "with",
    "category": "keyword",
    "subcategory": "Context & Pattern Matching",
    "title": "with — Contextual Binding & Match Target",
    "summary": "Binds expression targets into match evaluation or scoped contextual resources.",
    "syntax": "match target with:\n  case pattern: ...",
    "parameters": "target (expression)",
    "returns": "Evaluated branch result",
    "pairedWith": "match, case",
    "example": "role : \"admin\"\nmatch role with:\n    case \"admin\": display \"Superuser Access\"\n    case \"guest\": display \"Read Only\"\n    case _: display \"Unknown Role\"",
    "tags": [
      "with",
      "match",
      "context",
      "pattern"
    ]
  },
  {
    "id": "kw-case",
    "name": "case",
    "category": "keyword",
    "subcategory": "Pattern Branch",
    "title": "case — Pattern Matching Branch Selector",
    "summary": "Defines an individual matching branch and statement within a match expression.",
    "syntax": "case pattern : action",
    "parameters": "pattern (literal or wildcard `_`)",
    "returns": "Branch evaluation result",
    "pairedWith": "match, with",
    "example": "code : 200\nmatch code with:\n    case 200: display \"OK\"\n    case 404: display \"Not Found\"\n    case _: display \"Server Error\"",
    "tags": [
      "case",
      "match",
      "pattern",
      "branch"
    ]
  },
  {
    "id": "kw-in",
    "name": "in",
    "category": "keyword",
    "subcategory": "Collection & Range Traversal",
    "title": "in — Membership Predicate & Range Iterator",
    "summary": "Specifies range or collection iteration in loop headers and tests for element inclusion.",
    "syntax": "for element in collection:\n    ...",
    "parameters": "element (identifier), collection (array, range, or string)",
    "returns": "Iterates through members",
    "pairedWith": "for, iterate, step, range",
    "example": "for num in [10, 20, 30]:\n    display \"Number: \" + num",
    "tags": [
      "in",
      "loop",
      "collection",
      "iteration"
    ]
  },
  {
    "id": "kw-is",
    "name": "is",
    "category": "keyword",
    "subcategory": "Type & Identity Predicate",
    "title": "is — Dynamic Type & State Predicate",
    "summary": "Tests whether a variable conforms to a primitive type or numeric characteristic (even/odd).",
    "syntax": "expression is type_or_predicate",
    "parameters": "expression (any), type (num, str, bool, arr, entity, even, odd)",
    "returns": "bool",
    "pairedWith": "if, guard, even, odd",
    "example": "val : 42\nif val is num:\n    display \"Value is numeric\" ?color=#00FFCC\nif val is even:\n    display \"Value is an even integer\"",
    "tags": [
      "is",
      "typecheck",
      "predicate",
      "types"
    ]
  },
  {
    "id": "kw-even",
    "name": "even",
    "category": "keyword",
    "subcategory": "Numeric Predicate",
    "title": "even — Even Integer Predicate",
    "summary": "Used alongside the 'is' operator to test if an integer is divisible by 2.",
    "syntax": "number is even",
    "parameters": "number (num)",
    "returns": "bool",
    "pairedWith": "is, odd",
    "example": "count : 14\nif count is even:\n    display \"Even count detected\"",
    "tags": [
      "even",
      "predicate",
      "math",
      "integer"
    ]
  },
  {
    "id": "kw-odd",
    "name": "odd",
    "category": "keyword",
    "subcategory": "Numeric Predicate",
    "title": "odd — Odd Integer Predicate",
    "summary": "Used alongside the 'is' operator to test if an integer is not divisible by 2.",
    "syntax": "number is odd",
    "parameters": "number (num)",
    "returns": "bool",
    "pairedWith": "is, even",
    "example": "idx : 7\nif idx is odd:\n    display \"Odd index: \" + idx",
    "tags": [
      "odd",
      "predicate",
      "math",
      "integer"
    ]
  },
  {
    "id": "kw-iterate",
    "name": "iterate",
    "category": "keyword",
    "subcategory": "Loop Construct",
    "title": "iterate — Explicit Sequence Driver",
    "summary": "Initiates explicit iteration across numeric ranges or collection items.",
    "syntax": "iterate from start to end by step:\n    ...",
    "parameters": "start (num), end (num), step (num)",
    "returns": "Executes body for each iteration",
    "pairedWith": "from, to, by, step, loop",
    "example": "iterate from 1 to 5:\n    display \"Step count\"",
    "tags": [
      "iterate",
      "loop",
      "range",
      "iteration"
    ]
  },
  {
    "id": "kw-yield",
    "name": "yield",
    "category": "keyword",
    "subcategory": "Coroutine Generator",
    "title": "yield — Generator Value Suspension",
    "summary": "Suspends function execution and yields an intermediate value to the consumer.",
    "syntax": "yield value",
    "parameters": "value (any)",
    "returns": "Yielded element",
    "pairedWith": "func, reply, async",
    "example": "func countUp(max):\n    for i in 1 .. max:\n        yield i",
    "tags": [
      "yield",
      "generator",
      "coroutine",
      "async"
    ]
  },
  {
    "id": "kw-extern",
    "name": "extern",
    "category": "keyword",
    "subcategory": "Foreign Function Interface",
    "title": "extern — Dynamic Win32 / Native Shared Library FFI",
    "summary": "Declares and binds external dynamic symbols from system DLLs (e.g. kernel32.dll) for direct runtime invocation.",
    "syntax": "extern \"library.dll\" function_name(args)",
    "parameters": "library.dll (string), function_name (identifier)",
    "returns": "Native integer or pointer return value",
    "pairedWith": "def, func, load",
    "example": "extern \"kernel32.dll\" GetCurrentProcessId()\npid : GetCurrentProcessId()\ndisplay \"Native Win32 Process ID: \" + pid ?color=#00FFCC",
    "tags": [
      "extern",
      "ffi",
      "win32",
      "native",
      "dll"
    ]
  },
  {
    "id": "kw-lib",
    "name": "lib",
    "category": "keyword",
    "subcategory": "Module Declaration",
    "title": "lib — Modular Library Definition",
    "summary": "Declares a reusable library namespace containing exported functions, classes, and constants.",
    "syntax": "lib LibraryName:\n    export def method(): ...",
    "parameters": "LibraryName (identifier)",
    "returns": "Library module object",
    "pairedWith": "export, load, import, public",
    "example": "lib MathUtils:\n    export def doubleVal(n):\n        reply n * 2",
    "tags": [
      "lib",
      "library",
      "module",
      "export"
    ]
  },
  {
    "id": "kw-library",
    "name": "library",
    "category": "keyword",
    "subcategory": "Module Declaration",
    "title": "library — Canonical Module Definition Alias",
    "summary": "Full keyword alias for declaring modular library units and namespaces.",
    "syntax": "library MyLib:\n    ...",
    "parameters": "MyLib (identifier)",
    "returns": "Library namespace object",
    "pairedWith": "lib, export, import",
    "example": "library Geometry:\n    export def area(w, h):\n        reply w * h",
    "tags": [
      "library",
      "lib",
      "module",
      "namespace"
    ]
  },
  {
    "id": "kw-pkg",
    "name": "pkg",
    "category": "keyword",
    "subcategory": "Package Namespace",
    "title": "pkg — Package Declaration & Scoping",
    "summary": "Encapsulates source units into a distribution package namespace for the VerScript Package Manager.",
    "syntax": "pkg package.name",
    "parameters": "package.name (qualified identifier)",
    "returns": "Enforces package scope",
    "pairedWith": "import, export, lib",
    "example": "pkg org.verscript.net\nlib HttpClient:\n    ...",
    "tags": [
      "pkg",
      "package",
      "namespace",
      "distribution"
    ]
  },
  {
    "id": "kw-config",
    "name": "config",
    "category": "keyword",
    "subcategory": "Configuration & Directives",
    "title": "config — Compiler & Runtime Directive Block",
    "summary": "Declares execution configuration options, optimization levels, or runtime constraints for a script.",
    "syntax": "config:\n  key : value",
    "parameters": "Configuration key-value pairs",
    "returns": "Configures script runtime environment",
    "pairedWith": "pragma, header",
    "example": "config:\n    strictTypes : true\n    optimize : 2",
    "tags": [
      "config",
      "compiler",
      "runtime",
      "settings"
    ]
  },
  {
    "id": "kw-extends",
    "name": "extends",
    "category": "keyword",
    "subcategory": "Type Inheritance",
    "title": "extends — DataType Specialization & Inheritance",
    "summary": "Inherits and extends fields and methods from a base DataType or Class.",
    "syntax": "DataType SubType extends BaseType:\n    ...",
    "parameters": "BaseType (DataType identifier)",
    "returns": "Extended subtype definition",
    "pairedWith": "DataType, class",
    "example": "DataType Employee extends Person:\n    department : str",
    "tags": [
      "extends",
      "inheritance",
      "oop",
      "datatype"
    ]
  },
  {
    "id": "kw-unpack",
    "name": "unpack",
    "category": "keyword",
    "subcategory": "Destructuring Assignment",
    "title": "unpack — Structured Destructuring Assignment",
    "summary": "Unpacks elements from an array or entity fields directly into multiple variables.",
    "syntax": "unpack [var1, var2] : array_or_tuple",
    "parameters": "Target variable list and source collection",
    "returns": "Binds variables",
    "pairedWith": "set, :",
    "example": "coords : [100, 250]\nunpack [x, y] : coords\ndisplay \"X: \" + x + \", Y: \" + y",
    "tags": [
      "unpack",
      "destructuring",
      "array",
      "assignment"
    ]
  },
  {
    "id": "kw-ceil",
    "name": "ceil",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "ceil — Ceiling Rounding",
    "summary": "Rounds a numeric floating-point value upward to the nearest integer.",
    "syntax": "ceil(value)",
    "parameters": "value (num)",
    "returns": "num (ceiling integer)",
    "pairedWith": "floor, round",
    "example": "val : 4.12\ndisplay ceil(val)  ! Outputs 5",
    "tags": [
      "ceil",
      "math",
      "rounding",
      "float"
    ]
  },
  {
    "id": "kw-floor",
    "name": "floor",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "floor — Floor Rounding",
    "summary": "Rounds a numeric value downward to the nearest integer.",
    "syntax": "floor(value)",
    "parameters": "value (num)",
    "returns": "num (floor integer)",
    "pairedWith": "ceil, round",
    "example": "val : 8.89\ndisplay floor(val)  ! Outputs 8",
    "tags": [
      "floor",
      "math",
      "rounding",
      "float"
    ]
  },
  {
    "id": "kw-round",
    "name": "round",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "round — Nearest Integer Rounding",
    "summary": "Rounds a number to the nearest integer value using standard half-up rounding.",
    "syntax": "round(value)",
    "parameters": "value (num)",
    "returns": "num (nearest integer)",
    "pairedWith": "floor, ceil",
    "example": "display round(7.5)  ! Outputs 8",
    "tags": [
      "round",
      "math",
      "rounding",
      "numeric"
    ]
  },
  {
    "id": "kw-clamp",
    "name": "clamp",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "clamp — Range Value Boundary Clamping",
    "summary": "Constrains a value within a specified minimum and maximum range.",
    "syntax": "clamp(value, minVal, maxVal)",
    "parameters": "value (num), minVal (num), maxVal (num)",
    "returns": "num (clamped value)",
    "pairedWith": "min, max",
    "example": "hp : clamp(currentHp, 0, 100)\ndisplay \"Health: \" + hp",
    "tags": [
      "clamp",
      "math",
      "bounds",
      "range"
    ]
  },
  {
    "id": "kw-min",
    "name": "min",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "min — Minimum Value Determination",
    "summary": "Returns the lesser of two values, or the smallest item in an array.",
    "syntax": "min(a, b) or min(array)",
    "parameters": "a (num), b (num) or array of nums",
    "returns": "num (smallest value)",
    "pairedWith": "max, clamp",
    "example": "display min(14, 29)  ! Outputs 14",
    "tags": [
      "min",
      "math",
      "minimum",
      "compare"
    ]
  },
  {
    "id": "kw-max",
    "name": "max",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "max — Maximum Value Determination",
    "summary": "Returns the greater of two values, or the largest item in an array.",
    "syntax": "max(a, b) or max(array)",
    "parameters": "a (num), b (num) or array of nums",
    "returns": "num (largest value)",
    "pairedWith": "min, clamp",
    "example": "display max(14, 29)  ! Outputs 29",
    "tags": [
      "max",
      "math",
      "maximum",
      "compare"
    ]
  },
  {
    "id": "kw-exp",
    "name": "exp",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "exp — Natural Exponential Function",
    "summary": "Computes e raised to the power of x ($e^x$).",
    "syntax": "exp(x)",
    "parameters": "x (num)",
    "returns": "num ($e^x$)",
    "pairedWith": "ln, log2",
    "example": "display exp(1)  ! Approximately 2.71828",
    "tags": [
      "exp",
      "math",
      "exponential",
      "transcendental"
    ]
  },
  {
    "id": "kw-ln",
    "name": "ln",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "ln — Natural Logarithm (Base e)",
    "summary": "Computes the natural logarithm (base e) of a positive number.",
    "syntax": "ln(x)",
    "parameters": "x (positive num)",
    "returns": "num (natural logarithm)",
    "pairedWith": "exp, log, log2",
    "example": "display ln(2.71828)  ! Approximately 1.0",
    "tags": [
      "ln",
      "math",
      "logarithm",
      "natural"
    ]
  },
  {
    "id": "kw-log2",
    "name": "log2",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "log2 — Binary Logarithm (Base 2)",
    "summary": "Computes the base-2 logarithm of a positive number.",
    "syntax": "log2(x)",
    "parameters": "x (positive num)",
    "returns": "num (base-2 logarithm)",
    "pairedWith": "log, ln",
    "example": "display log2(256)  ! Outputs 8",
    "tags": [
      "log2",
      "math",
      "logarithm",
      "binary"
    ]
  },
  {
    "id": "kw-sqrt",
    "name": "sqrt",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "sqrt — Square Root",
    "summary": "Computes the principal non-negative square root of a number.",
    "syntax": "sqrt(x)",
    "parameters": "x (non-negative num)",
    "returns": "num ($sqrt{x}$)",
    "pairedWith": "rt, hypot",
    "example": "display sqrt(144)  ! Outputs 12",
    "tags": [
      "sqrt",
      "math",
      "root",
      "geometry"
    ]
  },
  {
    "id": "kw-rt",
    "name": "rt",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "rt — Arbitrary n-th Root",
    "summary": "Computes the arbitrary n-th root of a number.",
    "syntax": "rt(value, n)",
    "parameters": "value (num), n (num degree)",
    "returns": "num ($sqrt[n]{\text{value}}$)",
    "pairedWith": "sqrt, exp",
    "example": "display rt(27, 3)  ! Cube root = 3",
    "tags": [
      "rt",
      "root",
      "math",
      "algebra"
    ]
  },
  {
    "id": "kw-hypot",
    "name": "hypot",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "hypot — Euclidean Distance Hypotenuse",
    "summary": "Computes $sqrt{x^2 + y^2}$ without intermediate overflow or underflow.",
    "syntax": "hypot(x, y)",
    "parameters": "x (num), y (num)",
    "returns": "num (hypotenuse length)",
    "pairedWith": "sqrt, sin, cos",
    "example": "dist : hypot(3, 4)\ndisplay \"Hypotenuse: \" + dist  ! Outputs 5",
    "tags": [
      "hypot",
      "math",
      "geometry",
      "distance"
    ]
  },
  {
    "id": "kw-gcd",
    "name": "gcd",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "gcd — Greatest Common Divisor",
    "summary": "Computes the largest positive integer that divides two given integers without a remainder.",
    "syntax": "gcd(a, b)",
    "parameters": "a (int), b (int)",
    "returns": "int (greatest common divisor)",
    "pairedWith": "lcm, hcf",
    "example": "display gcd(48, 18)  ! Outputs 6",
    "tags": [
      "gcd",
      "math",
      "number-theory",
      "divisor"
    ]
  },
  {
    "id": "kw-hcf",
    "name": "hcf",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "hcf — Highest Common Factor",
    "summary": "Canonical alias for gcd.",
    "syntax": "hcf(a, b)",
    "parameters": "a (int), b (int)",
    "returns": "int",
    "pairedWith": "gcd, lcm",
    "example": "display hcf(36, 60)  ! Outputs 12",
    "tags": [
      "hcf",
      "gcd",
      "math",
      "divisor"
    ]
  },
  {
    "id": "kw-lcm",
    "name": "lcm",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "lcm — Least Common Multiple",
    "summary": "Computes the smallest positive integer that is divisible by both given numbers.",
    "syntax": "lcm(a, b)",
    "parameters": "a (int), b (int)",
    "returns": "int",
    "pairedWith": "gcd, hcf",
    "example": "display lcm(12, 15)  ! Outputs 60",
    "tags": [
      "lcm",
      "math",
      "multiple",
      "number-theory"
    ]
  },
  {
    "id": "kw-sin",
    "name": "sin",
    "category": "keyword",
    "subcategory": "Trigonometric Function",
    "title": "sin — Trigonometric Sine (Radians)",
    "summary": "Computes the trigonometric sine of an angle given in radians.",
    "syntax": "sin(radians)",
    "parameters": "radians (num)",
    "returns": "num (-1.0 to 1.0)",
    "pairedWith": "cos, tan, sinDeg",
    "example": "display sin(pi / 2)  ! Outputs 1",
    "tags": [
      "sin",
      "trig",
      "math",
      "geometry"
    ]
  },
  {
    "id": "kw-cos",
    "name": "cos",
    "category": "keyword",
    "subcategory": "Trigonometric Function",
    "title": "cos — Trigonometric Cosine (Radians)",
    "summary": "Computes the trigonometric cosine of an angle in radians.",
    "syntax": "cos(radians)",
    "parameters": "radians (num)",
    "returns": "num (-1.0 to 1.0)",
    "pairedWith": "sin, tan, cosDeg",
    "example": "display cos(0)  ! Outputs 1",
    "tags": [
      "cos",
      "trig",
      "math",
      "geometry"
    ]
  },
  {
    "id": "kw-tan",
    "name": "tan",
    "category": "keyword",
    "subcategory": "Trigonometric Function",
    "title": "tan — Trigonometric Tangent (Radians)",
    "summary": "Computes the trigonometric tangent of an angle in radians.",
    "syntax": "tan(radians)",
    "parameters": "radians (num)",
    "returns": "num (tangent ratio)",
    "pairedWith": "sin, cos",
    "example": "display tan(pi / 4)  ! Approximately 1",
    "tags": [
      "tan",
      "trig",
      "math",
      "geometry"
    ]
  },
  {
    "id": "kw-sindeg",
    "name": "sinDeg",
    "category": "keyword",
    "subcategory": "Trigonometric Function",
    "title": "sinDeg / sindeg — Trigonometric Sine (Degrees)",
    "summary": "Computes the sine of an angle directly specified in degrees.",
    "syntax": "sinDeg(degrees)",
    "parameters": "degrees (num)",
    "returns": "num (-1.0 to 1.0)",
    "pairedWith": "cosDeg, degToRad",
    "example": "display sinDeg(90)  ! Outputs 1",
    "tags": [
      "sindeg",
      "trig",
      "degrees",
      "geometry"
    ]
  },
  {
    "id": "kw-cosdeg",
    "name": "cosDeg",
    "category": "keyword",
    "subcategory": "Trigonometric Function",
    "title": "cosDeg / cosdeg — Trigonometric Cosine (Degrees)",
    "summary": "Computes the cosine of an angle directly specified in degrees.",
    "syntax": "cosDeg(degrees)",
    "parameters": "degrees (num)",
    "returns": "num (-1.0 to 1.0)",
    "pairedWith": "sinDeg, degToRad",
    "example": "display cosDeg(0)  ! Outputs 1",
    "tags": [
      "cosdeg",
      "trig",
      "degrees",
      "geometry"
    ]
  },
  {
    "id": "kw-degtorad",
    "name": "degToRad",
    "category": "keyword",
    "subcategory": "Angle Conversion",
    "title": "degToRad / degtorad — Degrees to Radians Conversion",
    "summary": "Converts an angle from degrees to radians ($d \times \frac{pi}{180}$).",
    "syntax": "degToRad(degrees)",
    "parameters": "degrees (num)",
    "returns": "num (radians)",
    "pairedWith": "radToDeg, pi",
    "example": "rad : degToRad(180)\ndisplay rad  ! Approximately 3.14159",
    "tags": [
      "degtorad",
      "trig",
      "conversion",
      "angle"
    ]
  },
  {
    "id": "kw-radtodeg",
    "name": "radToDeg",
    "category": "keyword",
    "subcategory": "Angle Conversion",
    "title": "radToDeg / radtodeg — Radians to Degrees Conversion",
    "summary": "Converts an angle from radians to degrees ($r \times \frac{180}{pi}$).",
    "syntax": "radToDeg(radians)",
    "parameters": "radians (num)",
    "returns": "num (degrees)",
    "pairedWith": "degToRad, pi",
    "example": "deg : radToDeg(pi)\ndisplay deg  ! Outputs 180",
    "tags": [
      "radtodeg",
      "trig",
      "conversion",
      "angle"
    ]
  },
  {
    "id": "kw-sign",
    "name": "sign",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "sign / sgn — Signum Function",
    "summary": "Extracts the sign of a number, returning -1 for negative numbers, 0 for zero, and +1 for positive numbers.",
    "syntax": "sign(value) or sgn(value)",
    "parameters": "value (num)",
    "returns": "int (-1, 0, or 1)",
    "pairedWith": "clamp",
    "example": "display sign(-42)  ! Outputs -1\ndisplay sgn(10)   ! Outputs 1",
    "tags": [
      "sign",
      "sgn",
      "math",
      "signum"
    ]
  },
  {
    "id": "kw-divrem",
    "name": "divRem",
    "category": "keyword",
    "subcategory": "Arithmetic Operation",
    "title": "divRem / divrem — Combined Division and Remainder",
    "summary": "Computes integer quotient and remainder simultaneously, returning a two-element tuple `[quotient, remainder]`.",
    "syntax": "divRem(numerator, denominator)",
    "parameters": "numerator (int), denominator (int)",
    "returns": "arr [quotient, remainder]",
    "pairedWith": "//, %",
    "example": "res : divRem(17, 5)\ndisplay \"Quotient: \" + res[0] + \", Remainder: \" + res[1]",
    "tags": [
      "divrem",
      "math",
      "division",
      "modulo"
    ]
  },
  {
    "id": "kw-iseven",
    "name": "isEven",
    "category": "keyword",
    "subcategory": "Numeric Predicate",
    "title": "isEven / iseven — Functional Even Predicate",
    "summary": "Functional call checking if an integer is even.",
    "syntax": "isEven(n)",
    "parameters": "n (int)",
    "returns": "bool (true if divisible by 2)",
    "pairedWith": "isOdd, is even",
    "example": "display isEven(10)  ! true",
    "tags": [
      "iseven",
      "predicate",
      "math",
      "parity"
    ]
  },
  {
    "id": "kw-isodd",
    "name": "isOdd",
    "category": "keyword",
    "subcategory": "Numeric Predicate",
    "title": "isOdd / isodd — Functional Odd Predicate",
    "summary": "Functional call checking if an integer is odd.",
    "syntax": "isOdd(n)",
    "parameters": "n (int)",
    "returns": "bool (true if odd)",
    "pairedWith": "isEven, is odd",
    "example": "display isOdd(7)  ! true",
    "tags": [
      "isodd",
      "predicate",
      "math",
      "parity"
    ]
  },
  {
    "id": "kw-lerp",
    "name": "lerp",
    "category": "keyword",
    "subcategory": "Interpolation Function",
    "title": "lerp — Linear Interpolation",
    "summary": "Calculates the linear interpolation between point a and point b for parameter t ($a + (b - a) \times t$).",
    "syntax": "lerp(start, end, t)",
    "parameters": "start (num), end (num), t (num from 0.0 to 1.0)",
    "returns": "num (interpolated value)",
    "pairedWith": "clamp",
    "example": "mid : lerp(0, 100, 0.5)\ndisplay \"Midpoint: \" + mid  ! Outputs 50",
    "tags": [
      "lerp",
      "math",
      "interpolation",
      "animation"
    ]
  },
  {
    "id": "kw-pi",
    "name": "pi",
    "category": "keyword",
    "subcategory": "Math Constant",
    "title": "pi — Archimedes' Mathematical Constant",
    "summary": "Standard mathematical ratio of a circle's circumference to its diameter ($approx 3.141592653589793$).",
    "syntax": "pi",
    "parameters": "None",
    "returns": "num (3.141592653589793)",
    "pairedWith": "tau, degToRad",
    "example": "circumference : 2 * pi * radius",
    "tags": [
      "pi",
      "constant",
      "math",
      "geometry"
    ]
  },
  {
    "id": "kw-tau",
    "name": "tau",
    "category": "keyword",
    "subcategory": "Math Constant",
    "title": "tau — Full Turn Circle Constant (2π)",
    "summary": "The circle constant representing one full turn in radians ($2pi approx 6.283185307179586$).",
    "syntax": "tau",
    "parameters": "None",
    "returns": "num (6.283185307179586)",
    "pairedWith": "pi, sin, cos",
    "example": "angle : tau * 0.25  ! Quarter turn (90 deg)",
    "tags": [
      "tau",
      "constant",
      "math",
      "circle"
    ]
  },
  {
    "id": "kw-phi",
    "name": "phi",
    "category": "keyword",
    "subcategory": "Math Constant",
    "title": "phi — Golden Ratio Constant",
    "summary": "The golden ratio constant $\frac{1 + sqrt{5}}{2} approx 1.618033988749895$.",
    "syntax": "phi",
    "parameters": "None",
    "returns": "num (1.618033988749895)",
    "pairedWith": "pi, sqrt",
    "example": "goldenWidth : height * phi",
    "tags": [
      "phi",
      "constant",
      "math",
      "golden-ratio"
    ]
  },
  {
    "id": "kw-inf",
    "name": "inf",
    "category": "keyword",
    "subcategory": "Math Constant",
    "title": "inf / infinity — Positive Infinity Constant",
    "summary": "Represents positive infinity in IEEE floating-point arithmetic and numeric limits.",
    "syntax": "inf or infinity",
    "parameters": "None",
    "returns": "num (Infinity)",
    "pairedWith": "min, max",
    "example": "minDist : inf\nfor d in distances:\n    if d < minDist: minDist : d",
    "tags": [
      "inf",
      "infinity",
      "constant",
      "limits"
    ]
  },
  {
    "id": "kw-complex",
    "name": "complex",
    "category": "keyword",
    "subcategory": "Complex Number Primitive",
    "title": "complex — Complex Number Constructor",
    "summary": "Instantiates a complex number with real and imaginary parts ($a + bi$).",
    "syntax": "complex(real, imag) or 3 + 4i",
    "parameters": "real (num), imag (num)",
    "returns": "complex number instance",
    "pairedWith": "real, imag, conj",
    "example": "z : complex(3, 4)\ndisplay \"Complex: \" + z",
    "tags": [
      "complex",
      "numbers",
      "imaginary",
      "math"
    ]
  },
  {
    "id": "kw-real",
    "name": "real",
    "category": "keyword",
    "subcategory": "Complex Number Component",
    "title": "real — Extract Real Component",
    "summary": "Extracts the real component from a complex number instance.",
    "syntax": "real(complex_val) or complex_val.real",
    "parameters": "complex_val (complex)",
    "returns": "num (real part)",
    "pairedWith": "imag, complex",
    "example": "z : complex(5, -2)\ndisplay \"Real: \" + real(z)  ! Outputs 5",
    "tags": [
      "real",
      "complex",
      "component",
      "math"
    ]
  },
  {
    "id": "kw-imag",
    "name": "imag",
    "category": "keyword",
    "subcategory": "Complex Number Component",
    "title": "imag — Extract Imaginary Component",
    "summary": "Extracts the imaginary component coefficient from a complex number instance.",
    "syntax": "imag(complex_val) or complex_val.imag",
    "parameters": "complex_val (complex)",
    "returns": "num (imaginary part)",
    "pairedWith": "real, complex",
    "example": "z : complex(5, -2)\ndisplay \"Imag: \" + imag(z)  ! Outputs -2",
    "tags": [
      "imag",
      "complex",
      "component",
      "math"
    ]
  },
  {
    "id": "kw-conj",
    "name": "conj",
    "category": "keyword",
    "subcategory": "Complex Number Operation",
    "title": "conj — Complex Conjugate",
    "summary": "Computes the complex conjugate of $a + bi$, returning $a - bi$.",
    "syntax": "conj(complex_val)",
    "parameters": "complex_val (complex)",
    "returns": "complex number ($a - bi$)",
    "pairedWith": "complex, real, imag",
    "example": "z : complex(3, 4)\nz_star : conj(z)\ndisplay \"Conjugate: \" + z_star  ! 3 - 4i",
    "tags": [
      "conj",
      "complex",
      "conjugate",
      "algebra"
    ]
  },
  {
    "id": "kw-terminal",
    "name": "terminal",
    "category": "keyword",
    "subcategory": "Terminal Control",
    "title": "terminal — Console & Terminal Subsystem Controller",
    "summary": "Accesses terminal control properties, cursor navigation, clear screen, and ANSI buffers.",
    "syntax": "terminal.clear(), terminal.title(str)",
    "parameters": "Terminal commands and methods",
    "returns": "Terminal controller",
    "pairedWith": "display, flush, focus",
    "example": "terminal.title(\"VerScript Studio Server\")\nterminal.clear()",
    "tags": [
      "terminal",
      "console",
      "cli",
      "ansi"
    ]
  },
  {
    "id": "kw-close",
    "name": "close",
    "category": "keyword",
    "subcategory": "Resource Lifecycle",
    "title": "close — Close Stream, Channel, or Session",
    "summary": "Closes an active file handle, network socket, concurrency channel, or terminal session.",
    "syntax": "close(handle)",
    "parameters": "handle (channel, file, or socket)",
    "returns": "None",
    "pairedWith": "chan, load",
    "example": "ch : chan<num>(5)\nclose(ch)",
    "tags": [
      "close",
      "resource",
      "channel",
      "lifecycle"
    ]
  },
  {
    "id": "kw-flush",
    "name": "flush",
    "category": "keyword",
    "subcategory": "I/O Control",
    "title": "flush — Flush Output Buffers",
    "summary": "Forces all pending output stream buffers to be written immediately to the console or file.",
    "syntax": "flush() or stream.flush()",
    "parameters": "None or stream target",
    "returns": "None",
    "pairedWith": "display, terminal",
    "example": "display \"Computing...\" ?inline=true\nflush()",
    "tags": [
      "flush",
      "io",
      "buffer",
      "terminal"
    ]
  },
  {
    "id": "kw-focus",
    "name": "focus",
    "category": "keyword",
    "subcategory": "UI / Terminal Focus",
    "title": "focus — Direct Viewport or Pane Focus",
    "summary": "Directs keyboard and cursor focus to a specified UI element, window pane, or terminal view.",
    "syntax": "focus(pane_identifier)",
    "parameters": "pane_identifier (str)",
    "returns": "None",
    "pairedWith": "terminal, screen",
    "example": "terminal.focus(\"output-pane\")",
    "tags": [
      "focus",
      "ui",
      "terminal",
      "interaction"
    ]
  },
  {
    "id": "kw-title",
    "name": "title",
    "category": "keyword",
    "subcategory": "Window / Terminal Metadata",
    "title": "title — Set Window or Document Title",
    "summary": "Sets the application window title or terminal tab title string.",
    "syntax": "title(title_string)",
    "parameters": "title_string (str)",
    "returns": "None",
    "pairedWith": "terminal, config",
    "example": "title \"VerScript Simulator v2.0\"",
    "tags": [
      "title",
      "window",
      "terminal",
      "metadata"
    ]
  },
  {
    "id": "kw-split",
    "name": "split",
    "category": "keyword",
    "subcategory": "Layout & Text Splitting",
    "title": "split — Split Panes or Delimited Strings",
    "summary": "Dual-purpose keyword: splits strings by a delimiter or splits terminal viewports into tiled panes.",
    "syntax": "str.split(delim) or terminal.split(direction)",
    "parameters": "delim (str) or direction (\"horizontal\" | \"vertical\")",
    "returns": "arr of strings or new pane handle",
    "pairedWith": "join, terminal",
    "example": "words : \"apple,banana,orange\".split(\",\")\ndisplay words[0]",
    "tags": [
      "split",
      "string",
      "terminal",
      "layout"
    ]
  },
  {
    "id": "kw-render",
    "name": "render",
    "category": "keyword",
    "subcategory": "Graphics & Rendering",
    "title": "render — Trigger Frame Rasterization",
    "summary": "Initiates rasterization of active scene geometry and visual elements onto the screen canvas.",
    "syntax": "render(scene, camera)",
    "parameters": "scene (scene object), camera (camera object)",
    "returns": "None",
    "pairedWith": "screen, scene, camera, frame",
    "example": "render(mainScene, mainCamera)",
    "tags": [
      "render",
      "graphics",
      "engine",
      "frame"
    ]
  },
  {
    "id": "kw-screen",
    "name": "screen",
    "category": "keyword",
    "subcategory": "Graphics Canvas",
    "title": "screen — Canvas & Viewport Surface Descriptor",
    "summary": "Configures and accesses the graphics display surface resolution, refresh rate, and pixel buffers.",
    "syntax": "screen(width, height, title)",
    "parameters": "width (int), height (int), title (str)",
    "returns": "screen canvas context",
    "pairedWith": "render, draw, pixel",
    "example": "screen(800, 600, \"VerScript 2D Sandbox\")",
    "tags": [
      "screen",
      "canvas",
      "graphics",
      "display"
    ]
  },
  {
    "id": "kw-world",
    "name": "world",
    "category": "keyword",
    "subcategory": "Spatial Environment",
    "title": "world — 3D Spatial Container & Physics Environment",
    "summary": "Defines the 3D spatial simulation coordinate space and physics world settings.",
    "syntax": "world(gravity, bounds)",
    "parameters": "gravity (vector), bounds (box)",
    "returns": "world container object",
    "pairedWith": "spawn, scene, light",
    "example": "simWorld : world([0, -9.8, 0])",
    "tags": [
      "world",
      "physics",
      "3d",
      "spatial"
    ]
  },
  {
    "id": "kw-draw",
    "name": "draw",
    "category": "keyword",
    "subcategory": "Immediate Graphics",
    "title": "draw — Immediate-Mode Shape Rendering",
    "summary": "Issues immediate 2D drawing instructions for geometric primitives.",
    "syntax": "draw(shape, x, y)",
    "parameters": "shape (rect, circle, line), coordinates",
    "returns": "None",
    "pairedWith": "rect, circle, fill, stroke",
    "example": "draw rect(100, 100, 50, 50) ?fill=#00FFCC",
    "tags": [
      "draw",
      "graphics",
      "2d",
      "shapes"
    ]
  },
  {
    "id": "kw-spawn",
    "name": "spawn",
    "category": "keyword",
    "subcategory": "Entity Instantiation",
    "title": "spawn — Instantiate Scene Entity",
    "summary": "Spawns a game object, actor, or geometry mesh into the active scene hierarchy.",
    "syntax": "spawn entity at position",
    "parameters": "entity (object), position (vector)",
    "returns": "spawned instance handle",
    "pairedWith": "world, scene, inst",
    "example": "player : spawn Entity(\"Hero\") at [0, 0, 0]",
    "tags": [
      "spawn",
      "entity",
      "scene",
      "instantiate"
    ]
  },
  {
    "id": "kw-camera",
    "name": "camera",
    "category": "keyword",
    "subcategory": "Camera & Projection",
    "title": "camera — Viewport Projection & Camera Controller",
    "summary": "Constructs and positions a virtual perspective or orthographic camera.",
    "syntax": "camera(fov, aspect, near, far)",
    "parameters": "fov (field of view in degrees), aspect (aspect ratio)",
    "returns": "camera controller instance",
    "pairedWith": "render, scene",
    "example": "cam : camera(60, 16/9, 0.1, 1000)\ncam.position : [0, 5, 10]",
    "tags": [
      "camera",
      "projection",
      "viewport",
      "3d"
    ]
  },
  {
    "id": "kw-light",
    "name": "light",
    "category": "keyword",
    "subcategory": "Scene Illumination",
    "title": "light — Illumination Source Descriptor",
    "summary": "Adds ambient, directional, or point lighting to a 3D scene.",
    "syntax": "light(type, color, intensity)",
    "parameters": "type (\"ambient\" | \"point\" | \"sun\"), color (hex), intensity (num)",
    "returns": "light instance",
    "pairedWith": "scene, world, render",
    "example": "sun : light(\"sun\", #FFFFFF, 1.2)",
    "tags": [
      "light",
      "illumination",
      "shader",
      "3d"
    ]
  },
  {
    "id": "kw-scene",
    "name": "scene",
    "category": "keyword",
    "subcategory": "Scene Graph",
    "title": "scene — Scene Graph Container",
    "summary": "Container managing all entities, lights, meshes, and cameras for a visual frame.",
    "syntax": "scene() or scene.add(entity)",
    "parameters": "None or entity list",
    "returns": "scene graph object",
    "pairedWith": "render, world, camera",
    "example": "lvl : scene()\nlvl.add(sun)\nlvl.add(player)",
    "tags": [
      "scene",
      "scenegraph",
      "entities",
      "graphics"
    ]
  },
  {
    "id": "kw-rect",
    "name": "rect",
    "category": "keyword",
    "subcategory": "Geometry Primitive",
    "title": "rect — 2D Rectangle Geometry Primitive",
    "summary": "Constructs a 2D rectangular shape with position, width, and height.",
    "syntax": "rect(x, y, width, height)",
    "parameters": "x (num), y (num), width (num), height (num)",
    "returns": "rect geometry shape",
    "pairedWith": "draw, circle, fill",
    "example": "box2d : rect(50, 50, 200, 100)",
    "tags": [
      "rect",
      "rectangle",
      "shape",
      "2d"
    ]
  },
  {
    "id": "kw-circle",
    "name": "circle",
    "category": "keyword",
    "subcategory": "Geometry Primitive",
    "title": "circle — 2D Circle Geometry Primitive",
    "summary": "Constructs a 2D circle with center coordinates and radius.",
    "syntax": "circle(centerX, centerY, radius)",
    "parameters": "centerX (num), centerY (num), radius (num)",
    "returns": "circle geometry shape",
    "pairedWith": "draw, rect, fill",
    "example": "coin : circle(150, 150, 25)",
    "tags": [
      "circle",
      "shape",
      "geometry",
      "2d"
    ]
  },
  {
    "id": "kw-line",
    "name": "line",
    "category": "keyword",
    "subcategory": "Geometry Primitive",
    "title": "line — Vector Line Segment",
    "summary": "Constructs a line segment between two coordinate points.",
    "syntax": "line(x1, y1, x2, y2)",
    "parameters": "Start and end coordinates",
    "returns": "line geometry shape",
    "pairedWith": "draw, stroke",
    "example": "ray : line(0, 0, 100, 100)",
    "tags": [
      "line",
      "vector",
      "geometry",
      "stroke"
    ]
  },
  {
    "id": "kw-box",
    "name": "box",
    "category": "keyword",
    "subcategory": "3D Mesh Primitive",
    "title": "box — 3D Cuboid Mesh Primitive",
    "summary": "Constructs a 3D cuboid mesh with width, height, and depth dimensions.",
    "syntax": "box(width, height, depth)",
    "parameters": "width (num), height (num), depth (num)",
    "returns": "3D mesh object",
    "pairedWith": "sphere, spawn, scene",
    "example": "crate : box(2, 2, 2)",
    "tags": [
      "box",
      "cube",
      "mesh",
      "3d"
    ]
  },
  {
    "id": "kw-sphere",
    "name": "sphere",
    "category": "keyword",
    "subcategory": "3D Mesh Primitive",
    "title": "sphere — 3D Spherical Mesh Primitive",
    "summary": "Constructs a 3D spherical mesh with a defined radius and radial segments.",
    "syntax": "sphere(radius, segments)",
    "parameters": "radius (num), segments (int)",
    "returns": "3D spherical mesh",
    "pairedWith": "box, spawn, scene",
    "example": "orb : sphere(1.5, 32)",
    "tags": [
      "sphere",
      "mesh",
      "3d",
      "geometry"
    ]
  },
  {
    "id": "kw-fill",
    "name": "fill",
    "category": "keyword",
    "subcategory": "Style Specification",
    "title": "fill — Surface Fill Color Specification",
    "summary": "Applies solid color, gradient, or texture fill to a 2D shape or material.",
    "syntax": "fill color_value or ?fill=#hex",
    "parameters": "color_value (hex, rgb, or color name)",
    "returns": "Applies fill style",
    "pairedWith": "stroke, draw, rect",
    "example": "draw circle(100, 100, 40) ?fill=#BD00FF",
    "tags": [
      "fill",
      "color",
      "style",
      "graphics"
    ]
  },
  {
    "id": "kw-stroke",
    "name": "stroke",
    "category": "keyword",
    "subcategory": "Style Specification",
    "title": "stroke — Border & Outline Specification",
    "summary": "Specifies outline color and border width for drawing primitives.",
    "syntax": "stroke(color, width) or ?stroke=#hex ?strokeWidth=2",
    "parameters": "color (hex), width (num)",
    "returns": "Applies stroke style",
    "pairedWith": "fill, draw, line",
    "example": "draw rect(20, 20, 80, 80) ?stroke=#00FFCC ?strokeWidth=2",
    "tags": [
      "stroke",
      "outline",
      "border",
      "graphics"
    ]
  },
  {
    "id": "kw-pixel",
    "name": "pixel",
    "category": "keyword",
    "subcategory": "Framebuffer Manipulation",
    "title": "pixel — Direct Framebuffer Pixel Access",
    "summary": "Sets or retrieves raw RGBA pixel color at $(x, y)$ coordinate on the active surface.",
    "syntax": "pixel(x, y) : color",
    "parameters": "x (int), y (int), color (hex / uint32)",
    "returns": "Reads or writes pixel",
    "pairedWith": "screen, draw",
    "example": "screen.pixel(400, 300) : #00FFCC",
    "tags": [
      "pixel",
      "framebuffer",
      "raster",
      "canvas"
    ]
  },
  {
    "id": "kw-frame",
    "name": "frame",
    "category": "keyword",
    "subcategory": "Animation & Delta Time",
    "title": "frame — Render Frame Clock & Delta Time",
    "summary": "Provides timing context and delta time ($Delta t$) within game loops and animation callbacks.",
    "syntax": "on frame(delta):\n    ...",
    "parameters": "delta (num elapsed seconds)",
    "returns": "Frame execution context",
    "pairedWith": "on, loop, render",
    "example": "on frame(dt):\n    player.x : player.x + (speed * dt)",
    "tags": [
      "frame",
      "deltatime",
      "animation",
      "loop"
    ]
  },
  {
    "id": "kw-infinity",
    "name": "infinity",
    "category": "keyword",
    "subcategory": "Math Constant",
    "title": "infinity — Full Keyword for Positive Infinity",
    "summary": "Represents positive infinity in numeric computations and upper limits.",
    "syntax": "infinity",
    "parameters": "None",
    "returns": "num (Infinity)",
    "pairedWith": "inf, min, max",
    "example": "val : infinity\nif x < val: display \"Within bounds\"",
    "tags": [
      "infinity",
      "inf",
      "constant",
      "limits"
    ]
  },
  {
    "id": "kw-method",
    "name": "method",
    "category": "keyword",
    "subcategory": "Class Method Declaration",
    "title": "method — Object & Class Method Declaration",
    "summary": "Declares a member function within a class definition with access to instance state.",
    "syntax": "method methodName(args):\n    ...",
    "parameters": "methodName (identifier), args",
    "returns": "Defines member method",
    "pairedWith": "class, func, def, reply",
    "example": "class Account:\n    method deposit(amount):\n        balance : balance + amount",
    "tags": [
      "method",
      "class",
      "oop",
      "function"
    ]
  },
  {
    "id": "kw-sgn",
    "name": "sgn",
    "category": "keyword",
    "subcategory": "Built-in Math Function",
    "title": "sgn — Signum Function Alias",
    "summary": "Returns -1 for negative numbers, 0 for zero, and +1 for positive numbers.",
    "syntax": "sgn(value)",
    "parameters": "value (num)",
    "returns": "int (-1, 0, or 1)",
    "pairedWith": "sign, clamp",
    "example": "display sgn(-15)  ! Outputs -1",
    "tags": [
      "sgn",
      "sign",
      "math",
      "signum"
    ]
  },
  {
    "id": "kw-sync",
    "name": "sync",
    "category": "keyword",
    "subcategory": "Concurrency & Synchronization",
    "title": "sync — Synchronous Block Execution",
    "summary": "Blocks and synchronizes execution until an async task, promise, or channel completes.",
    "syntax": "sync:\n  action()",
    "parameters": "None",
    "returns": "Blocks until completion",
    "pairedWith": "async, chan, emit",
    "example": "sync:\n    display \"Synchronous critical section\"",
    "tags": [
      "sync",
      "async",
      "concurrency",
      "channel"
    ]
  }
];
if (typeof module !== 'undefined' && module.exports) module.exports = { VERSCRIPT_HELP_DB };
if (typeof window !== 'undefined') window.VERSCRIPT_HELP_DB = VERSCRIPT_HELP_DB;
